import { Environment } from '../environment';
import { ICreateCloudAppParams, ICreateCloudAppResult, IDescribeCloudAppListParams, IDescribeCloudAppListResult, IDescribeCloudAppInfoParams, IDescribeCloudAppInfoResult, IDeleteCloudAppParams, IDeleteCloudAppResult, IDescribeCloudAppVersionParams, IDescribeCloudAppVersionResult, IDescribeCloudAppVersionListParams, IDescribeCloudAppVersionListResult, IDeleteCloudAppVersionParams, IDeleteCloudAppVersionResult, IDescribeCloudAppCosInfoParams, IDescribeCloudAppCosInfoResult, IUploadCloudAppCodeParams, IUploadCloudAppCodeResult } from './types';
export * from './types';
/**
 * CloudApp 统一部署服务
 * 提供 Web 应用的创建、查询、删除、版本管理等功能
 */
export declare class CloudAppService {
    private tcbService;
    private environment;
    constructor(environment: Environment);
    /**
     * 创建/更新 CloudApp 应用
     * @param params 创建参数
     */
    createApp(params: ICreateCloudAppParams): Promise<ICreateCloudAppResult>;
    /**
     * 获取 CloudApp 应用列表
     * @param params 查询参数
     */
    describeAppList(params: IDescribeCloudAppListParams): Promise<IDescribeCloudAppListResult>;
    /**
     * 获取 CloudApp 应用详情
     * @param params 查询参数
     */
    describeAppInfo(params: IDescribeCloudAppInfoParams): Promise<IDescribeCloudAppInfoResult>;
    /**
     * 删除 CloudApp 应用
     * @param params 删除参数
     */
    deleteApp(params: IDeleteCloudAppParams): Promise<IDeleteCloudAppResult>;
    /**
     * 获取 CloudApp 版本详情
     * 不指定 versionName 或 buildId 时返回最新版本
     * @param params 查询参数
     */
    describeAppVersion(params: IDescribeCloudAppVersionParams): Promise<IDescribeCloudAppVersionResult>;
    /**
     * 获取 CloudApp 版本列表
     * @param params 查询参数
     */
    describeAppVersionList(params: IDescribeCloudAppVersionListParams): Promise<IDescribeCloudAppVersionListResult>;
    /**
     * 删除 CloudApp 版本
     * @param params 删除参数
     */
    deleteAppVersion(params: IDeleteCloudAppVersionParams): Promise<IDeleteCloudAppVersionResult>;
    /**
     * 获取 CloudApp COS 上传信息（预签名 URL）
     * @param params 查询参数
     */
    describeCosInfo(params: IDescribeCloudAppCosInfoParams): Promise<IDescribeCloudAppCosInfoResult>;
    /**
     * 上传本地代码到 COS
     * 自动打包 ZIP 并上传到预签名 URL
     *
     * 注意：此方法不依赖应用是否已创建，可在创建应用前调用
     * 返回的 cosTimestamp 用于 createApp 时传入 staticConfig.cosTimestamp
     *
     * @param params 上传参数
     */
    uploadCode(params: IUploadCloudAppCodeParams): Promise<IUploadCloudAppCodeResult>;
    /**
     * 获取环境信息
     */
    private getEnvInfo;
    /**
     * 校验必填参数
     * @param params 参数对象
     * @param fields 必填字段列表
     */
    private validateRequiredParams;
}
