/**
 * CloudApp 统一部署服务类型定义
 * 支持 static-hosting（静态托管）和 http-function（预留）两种部署类型
 *
 * 命名规范：
 * - 入参接口（IXxxParams）：camelCase，通过 upperCaseObjKey 转换后透传给 API
 * - 返回值接口（IXxxResult）：PascalCase，与 API 响应字段保持一致
 */
/**
 * 部署类型
 * - static-hosting: 静态托管部署
 * - http-function: HTTP 云函数部署（预留）
 */
export type DeployType = 'static-hosting' | 'http-function';
/**
 * 构建类型
 * - GIT: 从 Git 仓库构建
 * - ZIP: 从 ZIP 包构建
 * - TEMPLATE: 从模板构建
 */
export type BuildType = 'GIT' | 'ZIP' | 'TEMPLATE';
/**
 * 构建状态
 */
export type BuildStatus = 'BUILDING' | 'SUCCESS' | 'FAILED';
/**
 * 构建命令配置（入参）
 */
export interface IStaticCmd {
    buildCmd?: string;
    installCmd?: string;
    deployCmd?: string;
}
/**
 * 静态环境变量配置（入参）
 */
export interface IStaticEnv {
    variables?: Array<{
        key: string;
        value: string;
    }>;
}
/**
 * 静态托管配置（入参）
 */
export interface IStaticConfig {
    /** 框架类型：vue、react、nextjs 等 */
    framework?: string;
    /** Node.js 版本，默认 20 */
    nodeJsVersion?: string;
    /** 访问路径 */
    appPath?: string;
    /** 构建目录 */
    buildPath?: string;
    /** ZIP 文件地址（BuildType=ZIP/TEMPLATE 时使用） */
    zipFileUrl?: string;
    /** COS 时间戳（通过 uploadCode 上传后获取，BuildType=ZIP 时使用） */
    cosTimestamp?: string;
    /** COS 文件后缀 */
    cosSuffix?: string;
    /** 代码源平台：github、gitlab、gitee */
    codeSource?: string;
    /** 代码仓库 */
    codeRepo?: string;
    /** 代码分支 */
    codeBranch?: string;
    /** 构建命令配置 */
    staticCmd?: IStaticCmd;
    /** 构建环境变量 */
    staticEnv?: IStaticEnv;
}
/**
 * 静态托管构建命令配置（API 响应）
 */
export interface StaticCmd {
    BuildCmd?: string;
    InstallCmd?: string;
    DeployCmd?: string;
}
/**
 * 静态托管环境变量配置（API 响应，对应文档 StaticEnvironment）
 */
export interface StaticEnv {
    /** 环境变量数组，可能为 null */
    Variables?: Array<{
        Key: string;
        Value: string;
    }> | null;
}
/**
 * 静态托管配置（API 响应，对应文档 StaticConfig）
 * 被 CreateCloudApp、DescribeCloudAppVersion、DescribeCloudAppVersionList 引用
 * 注意：所有字段均可能返回 null
 */
export interface CloudAppStaticConfig {
    /** 框架类型：vue、react、nextjs 等 */
    Framework?: string | null;
    /** Node.js 版本，默认 20 */
    NodeJsVersion?: string | null;
    /** 访问路径 */
    AppPath?: string | null;
    /** 构建目录 */
    BuildPath?: string | null;
    /** ZIP 文件地址（BuildType=ZIP/TEMPLATE 时使用） */
    ZipFileUrl?: string | null;
    /** COS 时间戳 */
    CosTimestamp?: string | null;
    /** COS 文件后缀 */
    CosSuffix?: string | null;
    /** 代码源平台：github、gitlab、gitee */
    CodeSource?: string | null;
    /** 代码仓库 */
    CodeRepo?: string | null;
    /** 代码分支 */
    CodeBranch?: string | null;
    /** 构建命令配置 */
    StaticCmd?: StaticCmd | null;
    /** 构建环境变量 */
    StaticEnv?: StaticEnv | null;
}
/**
 * 应用列表项（API 响应 CloudAppServiceItem）
 */
export interface CloudAppServiceItem {
    ServiceName: string;
    DeployType: string;
    Framework?: string;
    Domain?: string;
    AppPath?: string;
    CreateTime: string;
    LatestVersionName?: string;
    LatestStatus?: string;
    LatestBuildTime?: string;
}
/** @deprecated 请使用 CloudAppServiceItem */
export type CloudAppItem = CloudAppServiceItem;
/**
 * 版本信息（API 响应 CloudAppVersionItem）
 */
export interface CloudAppVersion {
    VersionName: string;
    BuildId: string;
    BuildType?: string;
    Status: string;
    Framework?: string;
    BuildTime?: string;
    StaticConfig?: CloudAppStaticConfig;
}
export interface ICreateCloudAppParams {
    /** 环境 ID（可选，默认从 Environment 获取） */
    envId?: string;
    /** 部署类型：static-hosting / http-function */
    deployType: DeployType;
    /** 服务名称 */
    serviceName: string;
    /** 构建类型：GIT / ZIP / TEMPLATE */
    buildType?: BuildType;
    /** 静态托管配置（deployType 为 static-hosting 时使用） */
    staticConfig?: IStaticConfig;
}
export interface ICreateCloudAppResult {
    ServiceName: string;
    BuildId: string;
    VersionName: string;
    RequestId: string;
}
export interface IDescribeCloudAppListParams {
    /** 环境 ID（可选） */
    envId?: string;
    /** 部署类型 */
    deployType: DeployType;
    /** 页码（从 1 开始） */
    pageNo?: number;
    /** 每页大小 */
    pageSize?: number;
    /** 搜索关键字，按应用名模糊搜索 */
    searchKey?: string;
}
export interface IDescribeCloudAppListResult {
    Total: number;
    ServiceList: CloudAppServiceItem[];
    RequestId: string;
}
export interface IDescribeCloudAppInfoParams {
    /** 环境 ID（可选） */
    envId?: string;
    /** 部署类型 */
    deployType: DeployType;
    /** 服务名称 */
    serviceName: string;
}
export interface IDescribeCloudAppInfoResult {
    ServiceName: string;
    DeployType: string;
    Framework?: string;
    Domain?: string;
    AppPath?: string;
    CreateTime: string;
    LatestVersionName?: string;
    LatestStatus?: string;
    LatestBuildTime?: string;
    RequestId: string;
}
export interface IDeleteCloudAppParams {
    /** 环境 ID（可选） */
    envId?: string;
    /** 部署类型 */
    deployType: DeployType;
    /** 服务名称 */
    serviceName: string;
}
export interface IDeleteCloudAppResult {
    Result: boolean;
    RequestId: string;
}
export interface IDescribeCloudAppVersionParams {
    /** 环境 ID（可选） */
    envId?: string;
    /** 部署类型 */
    deployType: DeployType;
    /** 服务名称 */
    serviceName: string;
    /** 版本名称（与 buildId 二选一） */
    versionName?: string;
    /** 构建 ID（与 versionName 二选一） */
    buildId?: string;
}
export interface IDescribeCloudAppVersionResult {
    BuildType: string;
    BuildId: string;
    Status: BuildStatus;
    Framework?: string;
    StaticConfig?: CloudAppStaticConfig;
    BuildTime?: string;
    RequestId: string;
}
export interface IDescribeCloudAppVersionListParams {
    /** 环境 ID（可选） */
    envId?: string;
    /** 部署类型 */
    deployType: DeployType;
    /** 服务名称 */
    serviceName: string;
    /** 页码（从 1 开始） */
    pageNo?: number;
    /** 每页大小 */
    pageSize?: number;
}
export interface IDescribeCloudAppVersionListResult {
    Total: number;
    VersionList: CloudAppVersion[] | null;
    RequestId: string;
}
export interface IDeleteCloudAppVersionParams {
    /** 环境 ID（可选） */
    envId?: string;
    /** 部署类型 */
    deployType: DeployType;
    /** 服务名称 */
    serviceName: string;
    /** 版本名称 */
    versionName: string;
}
export interface IDeleteCloudAppVersionResult {
    Result: boolean;
    RequestId: string;
}
export interface IDescribeCloudAppCosInfoParams {
    /** 环境 ID（可选） */
    envId?: string;
    /** 部署类型 */
    deployType: DeployType;
    /** 服务名称 */
    serviceName: string;
    /** Unix 时间戳（用于指定文件路径，不传则自动生成） */
    unixTimestamp?: string;
    /** 文件后缀（默认 .zip） */
    suffix?: string;
    /** 是否需要下载 URL */
    needDownload?: boolean;
}
export interface CosHeader {
    Key: string;
    Value: string;
}
export interface IDescribeCloudAppCosInfoResult {
    UploadUrl: string;
    UploadHeaders?: CosHeader[];
    DownloadUrl?: string;
    DownloadHeaders?: CosHeader[];
    UnixTimestamp: string;
    RequestId: string;
}
/**
 * 上传进度信息
 */
export interface IProgressData {
    loaded: number;
    total: number;
    percent: number;
}
/**
 * 上传代码参数
 */
export interface IUploadCloudAppCodeParams {
    /** 部署类型 */
    deployType: DeployType;
    /** 服务名称 */
    serviceName: string;
    /** 本地文件夹路径 */
    localPath: string;
    /** 忽略的文件/目录模式 */
    ignore?: string[];
    /** 进度回调 */
    onProgress?: (progress: IProgressData) => void;
}
/**
 * 上传代码结果
 */
export interface IUploadCloudAppCodeResult {
    /** COS 时间戳（用于 createApp 时传入 staticConfig.cosTimestamp） */
    cosTimestamp: string;
    /** Unix 时间戳（与 cosTimestamp 相同） */
    unixTimestamp: string;
}
