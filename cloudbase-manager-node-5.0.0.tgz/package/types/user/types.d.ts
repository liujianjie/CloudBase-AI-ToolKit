export interface EndUserInfo {
    UUId: string;
    WXOpenId: string;
    QQOpenId: string;
    Phone: string;
    Email: string;
    NickName: string;
    Gender: string;
    AvatarUrl: string;
    Country: string;
    Province: string;
    City: string;
    UpdateTime: string;
    CreateTime: string;
    IsAnonymous: boolean;
    IsDisabled: boolean;
    HasPassword: boolean;
    UserName: string;
}
export type EndUserStatus = 'ENABLE' | 'DISABLE';
export type TcbUserType = 'internalUser' | 'externalUser';
export type TcbUserStatus = 'ACTIVE' | 'BLOCKED';
export interface CreateUserOptions {
    name: string;
    uid?: string;
    type?: TcbUserType;
    password?: string;
    userStatus?: TcbUserStatus;
    nickName?: string;
    phone?: string;
    email?: string;
    avatarUrl?: string;
    description?: string;
}
export interface CreateUserResp {
    Uid: string;
}
export interface DescribeUserListOptions {
    pageNo?: number;
    pageSize?: number;
    name?: string;
    nickName?: string;
    phone?: string;
    email?: string;
}
export interface TcbUserItem {
    Uid?: string;
    Name?: string;
    Type?: 'internalUser' | 'externalUser';
    UserStatus?: 'ACTIVE' | 'BLOCKED';
    NickName?: string;
    Phone?: string;
    Email?: string;
    AvatarUrl?: string;
    Description?: string;
}
export interface DescribeUserListResp {
    Total: number;
    UserList: TcbUserItem[];
}
export interface ModifyUserOptions {
    uid: string;
    name?: string;
    type?: TcbUserType;
    password?: string;
    userStatus?: TcbUserStatus;
    nickName?: string;
    phone?: string;
    email?: string;
    avatarUrl?: string;
    description?: string;
}
export interface ModifyUserResp {
    Success: boolean;
}
export interface DeleteUsersOptions {
    uids: string[];
}
export interface DeleteUsersResp {
    SuccessCount: number;
    FailedCount: number;
}
