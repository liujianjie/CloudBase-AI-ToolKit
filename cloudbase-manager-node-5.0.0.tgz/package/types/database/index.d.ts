import { IServiceVersion, IExistsRes, CreateIndex, DropIndex, IndexInfo, TableInfo, Pager, IResponseInfo, CollectionDispension } from '../interfaces/';
import { Environment } from '../environment';
interface IDatabaseConfig {
    Tag: string;
}
interface IIndexiesInfo {
    CreateIndexes?: Array<CreateIndex>;
    DropIndexes?: Array<DropIndex>;
}
interface ITableInfo extends IResponseInfo {
    Indexes?: Array<IndexInfo>;
    IndexNum?: number;
}
interface IMgoQueryInfo {
    MgoLimit?: number;
    MgoOffset?: number;
}
/** 待执行命令参数 */
interface IMgoCommandParam {
    /** 表名 */
    TableName: string;
    /** 操作类型：UPDATE / QUERY / INSERT / DELETE / COMMAND */
    CommandType: string;
    /** 待执行命令（JSON 字符串） */
    Command: string;
}
/** MongoDB 连接器配置 */
interface IMongoConnector {
    /** 连接器实例 ID */
    InstanceId?: string;
    /** MongoDB 数据库名 */
    DatabaseName?: string;
}
/** RunCommands 请求参数 */
interface IRunCommandsOptions {
    /** 待执行命令列表 */
    MgoCommands: IMgoCommandParam[];
    /** 实例 ID，如 tnt-xxxx。不传则自动使用当前环境的数据库实例 ID */
    Tag?: string;
    /** 环境 ID。不传则自动使用当前环境 ID */
    EnvId?: string;
    /** Mongo 连接器实例信息 */
    MongoConnector?: IMongoConnector;
}
/** RunCommands 返回结果 */
interface IRunCommandsResult extends IResponseInfo {
    /** 返回结果，每个元素是一个 JSON 字符串 */
    Data: string[];
}
interface ICollectionInfo extends IResponseInfo {
    Collections: Array<TableInfo>;
    Pager: Pager;
}
interface ICollectionExistInfo extends IResponseInfo {
    IsCreated: boolean;
    ExistsResult: IExistsRes;
}
interface IDistributionInfo extends IResponseInfo {
    Collections: CollectionDispension;
    Count: number;
    Total: number;
}
interface IDatabaseMigrateQueryInfo extends IResponseInfo {
    Status: string;
    RecordSuccess: number;
    RecordFail: number;
    ErrorMsg: string;
    FileUrl: string;
}
interface IDatabaseImportAndExportInfo extends IResponseInfo {
    JobId: number;
}
/** 回档表格名称映射信息 */
interface IModifyTableNamesInfo {
    /** 原表名 */
    OldTableName: string;
    /** 新表名 */
    NewTableName: string;
}
/** 回档任务信息 */
interface IRestoreTask {
    /** 恢复任务ID */
    TaskId?: string;
    /** 任务状态 */
    Status?: string;
    /** 任务创建时间 */
    Time?: string;
    /** 环境ID */
    EnvId?: string;
    /** 恢复类型 */
    Type?: string;
}
/** 任意时间回档范围 */
interface IRestoreTableTimeRange {
    [key: string]: any;
}
/** 获取可回档表格返回结果 */
interface IDescribeRestoreTablesResult extends IResponseInfo {
    /** 可回档表格列表 */
    Tables: string[];
}
/** 获取回档任务返回结果 */
interface IDescribeRestoreTaskResult extends IResponseInfo {
    /** 回档任务列表 */
    Tasks: IRestoreTask[];
}
/** 获取可回档时间返回结果 */
interface IDescribeRestoreTimeResult extends IResponseInfo {
    /** 可回档时间列表 */
    RestoreTimes: string[];
    /** 任意时间回档列表 */
    RestoreTimeRanges: IRestoreTableTimeRange[];
}
/** 实例表格回档返回结果 */
interface IRestoreTCBTablesResult extends IResponseInfo {
    /** 流程ID */
    FlowId: number;
}
export declare class DatabaseService {
    static tcbServiceVersion: IServiceVersion;
    static flexdbServiceVersion: IServiceVersion;
    private environment;
    private envId;
    private dbOpService;
    private collOpService;
    private DEFAULT_MGO_OFFSET;
    private DEFAULT_MGO_LIMIT;
    constructor(environment: Environment);
    getCurrEnvironment(): Environment;
    getDatabaseConfig(): IDatabaseConfig;
    checkCollectionExists(collectionName: string): Promise<IExistsRes>;
    createCollection(collectionName: string): Promise<any>;
    deleteCollection(collectionName: string): Promise<any>;
    updateCollection(collectionName: string, indexiesInfo: IIndexiesInfo): Promise<any>;
    describeCollection(collectionName: string): Promise<ITableInfo>;
    listCollections(options?: IMgoQueryInfo): Promise<ICollectionInfo>;
    createCollectionIfNotExists(collectionName: string): Promise<ICollectionExistInfo>;
    checkIndexExists(collectionName: string, indexName: string): Promise<IExistsRes>;
    distribution(): Promise<IDistributionInfo>;
    migrateStatus(jobId: number): Promise<IDatabaseMigrateQueryInfo>;
    import(collectionName: string, file: any, options: any): Promise<IDatabaseImportAndExportInfo>;
    export(collectionName: string, file: any, options: any): Promise<IDatabaseImportAndExportInfo>;
    /**
     * 获取可回档表格
     * @param time 回档时间，格式 YYYY-MM-DD HH:MM:SS
     * @param filters 过滤器（可选）
     * @param instanceId 实例ID（可选，不传则自动使用当前环境的数据库实例 ID）
     * @returns 可回档表格列表
     */
    describeRestoreTables(time: string, filters?: string[], instanceId?: string): Promise<IDescribeRestoreTablesResult>;
    /**
     * 获取回档任务
     * @param instanceId 实例ID（可选，不传则自动使用当前环境的数据库实例 ID）
     * @returns 回档任务列表
     */
    describeRestoreTask(instanceId?: string): Promise<IDescribeRestoreTaskResult>;
    /**
     * 获取可回档时间
     * @param instanceId 实例ID（可选，不传则自动使用当前环境的数据库实例 ID）
     * @returns 可回档时间列表及任意时间回档列表
     */
    describeRestoreTime(instanceId?: string): Promise<IDescribeRestoreTimeResult>;
    /**
     * 实例表格回档
     * @param time 回档时间，格式 YYYY-MM-DD HH:MM:SS
     * @param modifyTableNamesInfo 回档表格信息（原表名 → 新表名映射）
     * @param instanceId 实例ID（可选，不传则自动使用当前环境的数据库实例 ID）
     * @returns 流程ID
     */
    restoreTables(time: string, modifyTableNamesInfo: IModifyTableNamesInfo[], instanceId?: string): Promise<IRestoreTCBTablesResult>;
    /**
     * 执行文档型数据库命令
     * @param options 命令参数（命令列表、可选的 Tag/EnvId/MongoConnector）
     * @returns 执行结果，Data 为 JSON 字符串数组
     */
    runCommands(options: IRunCommandsOptions): Promise<IRunCommandsResult>;
}
export {};
