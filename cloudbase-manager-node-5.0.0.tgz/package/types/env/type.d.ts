export interface CalculatePackageCreatePriceParams {
    packageId: string;
    region: string;
    period?: number;
    currency?: 'CNY' | 'USD';
}
export interface CalculatePackageRenewPriceParams {
    envId: string;
    period?: number;
    currency?: 'CNY' | 'USD';
}
export interface CalculatePackageModifyPriceParams {
    newPackageId: string;
    envId: string;
    currency?: 'CNY' | 'USD';
}
/**
 * 客户端限频配置
 */
export interface HTTPServiceQPSPerClient {
    LimitBy?: 'UserID' | 'ClientIP';
    LimitValue?: number;
}
/**
 * QPS限频策略
 */
export interface HTTPServiceRouteQPSPolicy {
    QPSTotal?: number;
    QPSPerClient?: HTTPServiceQPSPerClient;
}
/**
 * 路径重写
 */
export interface HTTPServicePathRewrite {
    StaticStorePrefix?: string;
    Prefix?: string;
}
/**
 * HTTP访问服务路由信息
 */
export interface HTTPServiceRoute {
    Path: string;
    PathRewrite?: HTTPServicePathRewrite;
    UpstreamResourceType: 'SCF' | 'CBR' | 'STATIC_STORE' | 'WEB_SCF' | 'LH';
    UpstreamResourceName: string;
    EnableSafeDomain: boolean;
    EnableAuth: boolean;
    EnablePathTransmission: boolean;
    QPSPolicy?: HTTPServiceRouteQPSPolicy;
    Enable: boolean;
    CreateTime: string;
    UpdateTime: string;
}
/**
 * 域名路由信息
 */
export interface HTTPServiceDomain {
    Domain: string;
    DomainType: 'HTTPSERVICE' | 'CBR' | 'ANYSERVICE' | 'AI_AGENT' | 'VM' | 'INTEGRATION_CALLBACK';
    AccessType: 'DIRECT' | 'CDN' | 'CUSTOM';
    CertId: string;
    Protocol: 'HTTP_AND_HTTPS' | 'HTTP_TO_HTTPS' | 'HTTPS_TO_HTTP';
    Cname: string;
    IsDefault: boolean;
    Enable: boolean;
    Status: 'PROCESSING' | 'FAIL' | 'SUCCESS';
    DNSStatus: 'OK' | 'INVALID';
    Routes?: HTTPServiceRoute[];
    CreateTime: string;
    UpdateTime: string;
}
/**
 * 过滤条件
 */
export interface HTTPServiceRouteFilter {
    Name?: 'Domain' | 'Path' | 'DomainType' | 'UpstreamResourceType';
    Values?: string[];
}
/**
 * DescribeHTTPServiceRoute 请求参数
 */
export interface DescribeHttpServiceRouteParams {
    EnvId: string;
    Filters?: HTTPServiceRouteFilter[];
    Offset?: number;
    Limit?: number;
}
/**
 * DescribeHTTPServiceRoute 返回结果
 */
export interface DescribeHttpServiceRouteRes {
    Domains?: HTTPServiceDomain[];
    OriginDomain: string;
    TotalCount: number;
    RequestId: string;
}
/**
 * HTTP访问服务路由参数（创建/修改）
 */
export interface HTTPServiceRouteParam {
    Path: string;
    UpstreamResourceType?: 'SCF' | 'CBR' | 'STATIC_STORE' | 'WEB_SCF' | 'LH';
    UpstreamResourceName?: string;
    PathRewrite?: HTTPServicePathRewrite;
    EnableSafeDomain?: boolean;
    EnableAuth?: boolean;
    EnablePathTransmission?: boolean;
    QPSPolicy?: HTTPServiceRouteQPSPolicy;
    Enable?: boolean;
}
/**
 * HTTP访问服务域名参数（创建/修改）
 */
export interface HTTPServiceDomainParam {
    Domain: string;
    AccessType?: 'DIRECT' | 'CDN' | 'CUSTOM';
    CertId?: string;
    Protocol?: 'HTTP_AND_HTTPS' | 'HTTP_TO_HTTPS' | 'HTTPS_TO_HTTP';
    CustomCname?: string;
    Enable?: boolean;
    Routes?: HTTPServiceRouteParam[];
}
/**
 * CreateHTTPServiceRoute 请求参数
 */
export interface CreateHttpServiceRouteParams {
    EnvId: string;
    Domain: HTTPServiceDomainParam;
}
/**
 * CreateHTTPServiceRoute 返回结果
 */
export interface CreateHttpServiceRouteRes {
    RequestId: string;
}
/**
 * ModifyHTTPServiceRoute 请求参数
 */
export interface ModifyHttpServiceRouteParams {
    EnvId: string;
    Domain: HTTPServiceDomainParam;
}
/**
 * ModifyHTTPServiceRoute 返回结果
 */
export interface ModifyHttpServiceRouteRes {
    RequestId: string;
}
/**
 * DeleteHTTPServiceRoute 请求参数
 */
export interface DeleteHttpServiceRouteParams {
    EnvId: string;
    Domain: string;
    Paths?: string[];
}
/**
 * DeleteHTTPServiceRoute 返回结果
 */
export interface DeleteHttpServiceRouteRes {
    RequestId: string;
}
/**
 * 绑定自定义域名的域名参数
 * 与 HTTPServiceDomainParam 类似，但不包含 Routes（绑定域名场景）
 */
export interface BindCustomDomainDomainParam {
    Domain: string;
    CertId: string;
    AccessType?: 'DIRECT' | 'CDN' | 'CUSTOM';
    Protocol?: 'HTTP_AND_HTTPS' | 'HTTP_TO_HTTPS' | 'HTTPS_TO_HTTP';
    Enable?: boolean;
    CustomCname?: string;
}
/**
 * BindCustomDomain 请求参数
 * 用于绑定自定义域名到 HTTP 访问服务
 * 底层调用 CreateHTTPServiceRoute API，但参数配置不同
 */
export interface BindCustomDomainParams {
    EnvId: string;
    Domain: BindCustomDomainDomainParam;
}
/**
 * BindCustomDomain 返回结果
 */
export interface BindCustomDomainRes {
    RequestId: string;
}
/**
 * DeleteCustomDomain 请求参数
 * 用于删除自定义域名（仅当域名下无路由绑定时可删除）
 */
export interface DeleteCustomDomainParams {
    EnvId: string;
    Domain: string;
}
/**
 * DeleteCustomDomain 返回结果
 */
export interface DeleteCustomDomainRes {
    RequestId: string;
}
