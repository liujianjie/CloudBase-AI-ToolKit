import { Environment } from '../environment';
import { IResponseInfo, AuthDomain, EnvInfo, LoginConfigItem, ICheckTcbServiceRes, ICreatePostpayRes, EnvBillingInfoItem, PriceResult } from '../interfaces';
import { CalculatePackageCreatePriceParams, CalculatePackageRenewPriceParams, CalculatePackageModifyPriceParams, DescribeHttpServiceRouteParams, DescribeHttpServiceRouteRes, CreateHttpServiceRouteParams, CreateHttpServiceRouteRes, ModifyHttpServiceRouteParams, ModifyHttpServiceRouteRes, DeleteHttpServiceRouteParams, DeleteHttpServiceRouteRes, BindCustomDomainParams, BindCustomDomainRes, DeleteCustomDomainParams, DeleteCustomDomainRes } from './type';
import { CreateBillingDealParams, CreateEnvParams, BaasPackageInfo, DescribeBaasPackageListParams, ModifyEnvPlanParams, RenewEnvParams, DestroyEnvParams, DescribeEnvsParams, DescribeEnvAccountCircleParams, DescribeEnvAccountCircleRes, DescribeCreditsUsageDetailParams, EnvPkgCreditsUsage } from '../interfaces/tcb.interface';
type SOURCE = 'miniapp' | 'qcloud';
interface IDeleteDomainRes {
    RequestId: string;
    Deleted: number;
}
interface IAuthDomainsRes {
    RequestId: string;
    Domains: AuthDomain[];
}
interface IListEnvRes {
    RequestId: string;
    EnvList: EnvInfo[];
}
interface IEnvLoginConfigRes {
    RequestId: string;
    ConfigList: LoginConfigItem[];
}
interface VerificationConfig {
    Type: string;
    Name: string;
    Method: string;
}
interface MFALoginConfig {
    On: string;
    Sms: string;
    Email: string;
    RequiredBindPhone: string;
    Topt: string;
}
interface PasswordUpdateLoginConfig {
    FirstLoginUpdate: boolean;
    PeriodUpdate: boolean;
    PeriodValue: number;
    PeriodType: string;
}
interface ILoginStrategy {
    Data: {
        PhoneLogin: boolean;
        EmailLogin: boolean;
        AnonymousLogin: boolean;
        UsernameLogin: boolean;
        PhoneNumberLogin: boolean;
        Mfa: boolean;
        SmsVerificationConfig: VerificationConfig;
        MfaConfig?: MFALoginConfig;
        PwdUpdateStrategy?: PasswordUpdateLoginConfig;
    };
}
interface IModifyLoginStrategy {
    EnvId: string;
    PhoneNumberLogin: boolean;
    EmailLogin: boolean;
    AnonymousLogin: boolean;
    UserNameLogin: boolean;
    SmsVerificationConfig?: VerificationConfig;
    Mfa?: boolean;
    MfaConfig?: MFALoginConfig;
    PwdUpdateStrategy?: PasswordUpdateLoginConfig;
}
interface IInitParam {
    Channel?: string;
    Source?: string;
}
export declare class EnvService {
    private environment;
    private envId;
    private cloudService;
    private envType?;
    private commonService;
    private billingService;
    constructor(environment: Environment);
    /**
     * 列出所有环境
     * @returns {Promise<IListEnvRes>}
     */
    listEnvs(): Promise<IListEnvRes>;
    /**
     * 拉取安全域名列表
     * @returns {Promise<IAuthDomainsRes>}
     */
    getEnvAuthDomains(): Promise<IAuthDomainsRes>;
    /**
     * 添加环境安全域名
     * @param {string[]} domains 域名字符串数组
     * @returns {Promise<IResponseInfo>}
     */
    createEnvDomain(domains: string[]): Promise<IResponseInfo>;
    /**
     * 删除环境安全域名
     * @param {string[]} domainIds 域名字符串数组
     * @returns {Promise<IDeleteDomainRes>}
     */
    deleteEnvDomain(domains: string[]): Promise<IDeleteDomainRes>;
    /**
     * 检查tcb服务是否开通
     * @returns {Promise<ICheckTcbServiceRes>}
     * @memberof CamService
     */
    checkTcbService(): Promise<ICheckTcbServiceRes>;
    /**
     * 初始化TCB
     * @returns {Promise<IResponseInfo>}
     * @memberof EnvService
     */
    initTcb(param: IInitParam): Promise<IResponseInfo>;
    /**
     * 开通后付费套餐
     * @param {string} envId
     * @param {SOURCE} [source]
     * @returns {Promise<ICreatePostpayRes>}
     * @memberof EnvService
     */
    CreatePostpayPackage(envId: string, source?: SOURCE): Promise<ICreatePostpayRes>;
    /**
     * 销毁环境
     * @param {string} envId
     * @returns {Promise<IResponseInfo>}
     * @memberof EnvService
     */
    destroyEnv(envId: string): Promise<IResponseInfo>;
    /**
     * 销毁环境（完整传参）
     */
    destroyEnvWithParams(params: DestroyEnvParams): Promise<IResponseInfo>;
    /**
     * 获取环境信息
     * @returns {Promise<IEnvInfoRes>}
     */
    getEnvInfo(): Promise<{
        EnvInfo: EnvInfo;
        RequestId: string;
    }>;
    /**
     * 获取环境列表
     */
    describeEnvs(params: DescribeEnvsParams): Promise<{
        RequestId: string;
        EnvList: EnvInfo[];
        Total: number;
    }>;
    /**
     * 修改环境名称
     * @param {string} alias 环境名称
     * @returns {Promise<IResponseInfo>}
     */
    updateEnvInfo(alias: string): Promise<IResponseInfo>;
    /**
     * 拉取登录配置列表
     * @deprecated 请使用 getLoginConfigListV2 代替
     * @returns {Promise<IEnvLoginConfigRes>}
     */
    getLoginConfigList(): Promise<IEnvLoginConfigRes>;
    /**
     * 拉取登录配置列表
     */
    getLoginConfigListV2(): Promise<ILoginStrategy>;
    /**
     * 创建登录方式
     * 'WECHAT-OPEN'：微信开放平台
     * 'WECHAT-PUBLIC'：微信公众平台
     * @param {('WECHAT-OPEN' | 'WECHAT-PUBLIC')} platform 'WECHAT-OPEN' | 'WECHAT-PUBLIC'
     * @param {string} appId 微信 appId
     * @param {string} appSecret 微信 appSecret
     * @returns {Promise<IResponseInfo>}
     */
    createLoginConfig(platform: 'WECHAT-OPEN' | 'WECHAT-PUBLIC' | 'QQ' | 'ANONYMOUS' | 'USERNAME', appId: string, appSecret?: string): Promise<IResponseInfo>;
    /**
     * 更新登录方式配置
     * @param {string} configId 配置 Id，从配置列表中获取
     * @param {string} [status='ENABLE'] 是否启用 'ENABLE', 'DISABLE' ，可选
     * @param {string} [appId=''] 微信 appId，可选
     * @param {string} [appSecret=''] 微信 appSecret，可选
     * @returns {Promise<IResponseInfo>}
     * @deprecated 请使用 updateLoginConfigV2 代替
     */
    updateLoginConfig(configId: string, status?: string, appId?: string, appSecret?: string): Promise<IResponseInfo>;
    /**
     * 更新登录方式配置
     * @param {IModifyLoginStrategy} options
     * @returns {Promise<boolean>}
     */
    updateLoginConfigV2(options: IModifyLoginStrategy): Promise<boolean>;
    createCustomLoginKeys(): Promise<{
        PrivateKey: string;
        KeyID: string;
        RequestId: string;
    }>;
    /**
     * 创建环境订单
     */
    createBillingDeal(params: CreateBillingDealParams): Promise<{
        EnvId: string;
        TranId: string;
        RequestId: string;
    }>;
    /**
     * 取消未支付的订单
     */
    cancelDeal(params: {
        TranId: string;
        UserClientIp: string;
        WxAppId?: string;
    }): Promise<{
        RequestId: string;
    }>;
    /**
     * 删除已取消的订单
     */
    /**
     * 创建环境
     */
    createEnv(params: CreateEnvParams): Promise<{
        EnvId: string;
        RequestId: string;
    }>;
    /**
     * 获取新套餐
     */
    describeBaasPackageList(params: DescribeBaasPackageListParams): Promise<{
        PackageList: BaasPackageInfo[];
        RequestId: string;
    }>;
    /**
     * 新购套餐询价
     */
    calculatePackageCreatePrice(params: CalculatePackageCreatePriceParams): Promise<PriceResult>;
    /**
     * 续费套餐询价
     */
    calculatePackageRenewPrice(params: CalculatePackageRenewPriceParams): Promise<PriceResult>;
    /**
     * 变配套餐询价
     */
    calculatePackageModifyPrice(params: CalculatePackageModifyPriceParams): Promise<PriceResult>;
    /**
     * 更新云开发环境套餐
     */
    modifyEnvPlan(params: ModifyEnvPlanParams): Promise<IResponseInfo>;
    /**
     * 获取计费相关信息
     */
    describeBillingInfo(params: {
        EnvId?: string;
    }): Promise<{
        EnvBillingInfoList: EnvBillingInfoItem[];
        RequestId: string;
    }>;
    /**
     * 续费云开发环境
     */
    renewEnv(params: RenewEnvParams): Promise<IResponseInfo>;
    /**
     * 查询环境计费周期
     */
    describeEnvAccountCircle(params: DescribeEnvAccountCircleParams): Promise<DescribeEnvAccountCircleRes>;
    /**
     * 获取资源点用量明细
     */
    describeCreditsUsageDetail(params: DescribeCreditsUsageDetailParams): Promise<{
        Usages: EnvPkgCreditsUsage[];
        RequestId: string;
    }>;
    /**
     * 查询HTTP访问服务域名路由信息
     * @param {DescribeHttpServiceRouteParams} params 查询参数
     * @returns {Promise<DescribeHttpServiceRouteRes>}
     */
    describeHttpServiceRoute(params: DescribeHttpServiceRouteParams): Promise<DescribeHttpServiceRouteRes>;
    /**
     * 创建HTTP访问服务域名路由
     * @param {CreateHttpServiceRouteParams} params 创建参数
     * @returns {Promise<CreateHttpServiceRouteRes>}
     */
    createHttpServiceRoute(params: CreateHttpServiceRouteParams): Promise<CreateHttpServiceRouteRes>;
    /**
     * 修改HTTP访问服务域名路由
     * @param {ModifyHttpServiceRouteParams} params 修改参数
     * @returns {Promise<ModifyHttpServiceRouteRes>}
     */
    modifyHttpServiceRoute(params: ModifyHttpServiceRouteParams): Promise<ModifyHttpServiceRouteRes>;
    /**
     * 删除HTTP访问服务域名路由
     * @param {DeleteHttpServiceRouteParams} params 删除参数
     * @returns {Promise<DeleteHttpServiceRouteRes>}
     */
    deleteHttpServiceRoute(params: DeleteHttpServiceRouteParams): Promise<DeleteHttpServiceRouteRes>;
    /**
     * 绑定自定义域名到HTTP访问服务
     * 底层调用 CreateHTTPServiceRoute API，专用于域名绑定场景
     * @param {BindCustomDomainParams} params 绑定参数
     * @returns {Promise<BindCustomDomainRes>}
     */
    bindCustomDomain(params: BindCustomDomainParams): Promise<BindCustomDomainRes>;
    /**
     * 删除自定义域名
     * 仅当域名下无路由绑定时可删除，否则抛出错误
     * @param {DeleteCustomDomainParams} params 删除参数
     * @returns {Promise<DeleteCustomDomainRes>}
     */
    deleteCustomDomain(params: DeleteCustomDomainParams): Promise<DeleteCustomDomainRes>;
    private getCOSDomains;
    private modifyCosCorsDomain;
    private getCos;
    private getStorageConfig;
    private parseBillTags;
}
export {};
