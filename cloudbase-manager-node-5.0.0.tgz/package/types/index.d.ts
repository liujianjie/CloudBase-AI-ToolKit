import { EnvService } from './env';
import { FunctionService } from './function';
import { CloudRunService } from './cloudrun';
import { AgentService } from './agent';
import { StorageService } from './storage';
import { DatabaseService } from './database';
import { LogService } from './log';
import { CommonService } from './common';
import { HostingService } from './hosting';
import { Environment } from './environment';
import { EnvironmentManager } from './environmentManager';
import { ThirdService } from './third';
import { AccessService } from './access';
import { UserService } from './user';
import { CloudBaseRunService } from './cloudBaseRun';
import { MysqlService } from './mysql';
import { DocsService } from './docs';
import { PermissionService } from './permission';
import { CloudAppService } from './cloudApp';
interface CloudBaseConfig {
    secretId?: string;
    secretKey?: string;
    token?: string;
    envId?: string;
    proxy?: string;
    region?: string;
    envType?: string;
    useInternalEndpoint?: boolean;
    internalEndpointRegion?: string;
}
declare class CloudBase {
    private static cloudBase;
    /**
     * init 初始化 为单例
     *
     * @static
     * @param {ManagerConfig} config
     * @returns {CloudBase}
     * @memberof CloudBase
     */
    static init(config: CloudBaseConfig): CloudBase;
    private context;
    private cloudBaseConfig;
    private environmentManager;
    private docsService;
    constructor(config?: CloudBaseConfig);
    addEnvironment(envId: string): void;
    currentEnvironment(): Environment;
    get functions(): FunctionService;
    get cloudrun(): CloudRunService;
    get agent(): AgentService;
    get storage(): StorageService;
    get database(): DatabaseService;
    get hosting(): HostingService;
    get access(): AccessService;
    get mysql(): MysqlService;
    /**
     * 云托管服务（CloudBaseRun）
     * 提供云托管版本流量配置等能力
     * @deprecated 请使用 cloudBaseRun 代替，避免与 cloudAppService 混淆
     */
    get cloudApp(): CloudBaseRunService;
    /**
     * 云托管服务（CloudBaseRun）
     * 提供云托管版本流量配置等能力
     */
    get cloudBaseRun(): CloudBaseRunService;
    /**
     * 云应用服务（CloudApp 统一部署）
     * 提供 Web 应用的创建、部署、版本管理等能力
     */
    get cloudAppService(): CloudAppService;
    /**
     * 获取云应用服务
     */
    getCloudAppService(): CloudAppService;
    commonService(service?: string, version?: string): CommonService;
    get env(): EnvService;
    get log(): LogService;
    get third(): ThirdService;
    get user(): UserService;
    get permission(): PermissionService;
    get docs(): DocsService;
    getEnvironmentManager(): EnvironmentManager;
    getManagerConfig(): CloudBaseConfig;
    get isInternalEndpoint(): Boolean;
}
export = CloudBase;
