/**
 * Agent 类型
 */
export type AgentType = 'scf' | 'tcbr';
/**
 * 运行时版本
 */
export type RuntimeVersion = 'Nodejs20.19' | 'Nodejs18.15' | 'Nodejs16.13' | 'Nodejs14.18' | 'Python3.10' | 'Python3.9' | 'Python3.7' | 'Php8.0' | 'Php7.4' | 'Go1' | 'Java11' | 'Java8';
/**
 * 会话来源
 */
export type SessionSource = 'HEADER' | 'COOKIE' | 'QUERY_STRING';
/**
 * 会话配置
 */
export interface ISessionConfig {
    /** 会话来源，默认 'HEADER' */
    SessionSource?: SessionSource;
    /** 会话名称，5-40字符，字母开头 */
    SessionName?: string;
    /** 单实例并发会话数，1-100，默认 1 */
    MaximumConcurrencySessionPerInstance?: number;
    /** 会话最长生命周期（秒），1-604800，默认 21600 */
    MaximumTTLInSeconds?: number;
    /** 会话最长空闲时间（秒），不超过 TTL，默认 1800 */
    MaximumIdleTimeInSeconds?: number;
    /** 单实例最大并发数，1-100，默认 50 */
    MaxConcurrency?: number;
}
/**
 * 创建 Agent 的参数
 * 支持两种方式：
 * 1. 传入 cwd 代码目录，自动打包上传
 * 2. 传入 ZipFile / CosBucketRegion + TempCosObjectName，直接上传
 */
export interface ICreateAgentParams {
    /** Agent 名称 */
    Name: string;
    /** Agent ID，不传则自动生成 */
    AgentId?: string;
    /** 环境变量 */
    envVariables?: Record<string, string>;
    /** 运行时版本 */
    Runtime: RuntimeVersion;
    /** 超时时间（秒），1-900，默认 3 */
    Timeout?: number;
    /** 函数运行时内存大小（MB），可选 64、128-3072（128为阶梯），默认 128 */
    MemorySize?: number;
    /** 是否自动安装依赖，默认 false */
    InstallDependency?: boolean;
    /** 会话配置 */
    SessionConfig?: ISessionConfig;
    /** 代码目录路径 */
    cwd?: string;
    /** 忽略的文件模式 */
    ignore?: string | string[];
    /** 部署方式：zip（直接上传）或 cos（COS 上传，大文件推荐） */
    deployMode?: 'zip' | 'cos';
    /** Base64 编码的 ZIP 文件内容 */
    ZipFile?: string;
    /** COS Bucket 区域 */
    CosBucketRegion?: string;
    /** COS 临时对象名称 */
    TempCosObjectName?: string;
}
/**
 * 仓库信息
 */
export interface IRepoInfo {
    /** Git 仓库地址或模板下载地址 */
    Repo: string;
    /** 来源标识，如 'template' */
    Source: string;
}
/**
 * 通过镜像创建 TCBR Agent 的参数
 */
export interface ICreateTcbrAgentByImageParams {
    /** Agent 名称 */
    Name: string;
    /** Agent ID */
    AgentId: string;
    /** 模板标识符 */
    Template: string;
    /** 环境变量 */
    envVariables?: Record<string, string>;
    /** Docker 镜像 URL */
    ImageUrl: string;
    /** 仓库信息 */
    RepoInfo: IRepoInfo;
    /** 头像 URL */
    Avatar?: string;
    /** 简介 */
    Introduction?: string;
}
/**
 * 通过代码包创建 TCBR Agent 的参数
 */
export interface ICreateTcbrAgentByPackageParams {
    /** Agent 名称 */
    Name: string;
    /** Agent ID */
    AgentId: string;
    /** 模板标识符 */
    Template: string;
    /** 环境变量 */
    envVariables?: Record<string, string>;
    /** 代码包名称（上传后获取） */
    PackageName: string;
    /** 代码包版本（上传后获取） */
    PackageVersion: string;
    /** 来源标识，如 'aiAgentWithConfigYaml' */
    Source?: string;
    /** 头像 URL */
    Avatar?: string;
    /** 简介 */
    Introduction?: string;
}
/**
 * 通过本地代码创建 TCBR Agent 的参数（自动上传）
 */
export interface ICreateTcbrAgentByCodeParams {
    /** Agent 名称 */
    Name: string;
    /** Agent ID */
    AgentId: string;
    /** 模板标识符 */
    Template: string;
    /** 环境变量 */
    envVariables?: Record<string, string>;
    /** 来源标识 */
    Source?: string;
    /** 头像 URL */
    Avatar?: string;
    /** 简介 */
    Introduction?: string;
}
/**
 * 查询 Agent 列表的参数
 */
export interface IDescribeAgentListParams {
    /** 每页数量，默认 20 */
    PageSize?: number;
    /** 页码，默认 1 */
    PageNumber?: number;
    /** 指定 Agent ID（查询单个） */
    AgentId?: string;
}
/**
 * Agent 信息
 */
export interface IAgentInfo {
    /** Agent ID */
    AgentId: string;
    /** Agent 名称 */
    Name: string;
    /** Agent 类型 */
    AgentType: AgentType;
    /** 简介 */
    Introduction?: string;
    /** 头像 */
    Avatar?: string;
    /** 背景图 */
    Background?: string;
    /** 标签 */
    Tags?: string[];
    /** 创建时间 */
    CreateTime?: string;
    /** 更新时间 */
    UpdateTime?: string;
    /** 状态 */
    Status?: string;
    /** 服务 ID */
    ServiceId?: string;
}
/**
 * Agent 列表响应
 */
export interface IDescribeAgentListResponse {
    /** Agent 列表 */
    AgentList: IAgentInfo[];
    /** 总数 */
    Total: number;
    /** 请求 ID */
    RequestId: string;
}
/**
 * Agent 详情响应（包含底层资源状态）
 */
export interface IDescribeAgentResponse {
    /** Agent 基本信息 */
    AgentInfo: IAgentInfo | null;
    /** Agent 是否已部署完成且可用 */
    IsReady: boolean;
    /** 不可用时的原因说明 */
    NotReadyReason?: string;
    /** 请求 ID */
    RequestId: string;
}
/**
 * 删除 Agent 的参数
 */
export interface IDeleteAgentParams {
    /** Agent ID */
    AgentId: string;
}
/**
 * 更新 Agent 的参数（通用）
 * 会自动判断 Agent 类型并调用对应的更新方法
 */
export interface IUpdateAgentParams {
    /** Agent ID（必填） */
    AgentId: string;
    /** 代码目录路径（可选，不传则不更新代码） */
    cwd?: string;
    /** Base64 编码的 ZIP 文件内容（与 cwd 二选一，仅 SCF 类型） */
    ZipFile?: string;
    /** 环境变量 */
    envVariables?: Record<string, string>;
    /** 运行时版本 */
    Runtime?: RuntimeVersion;
    /** 超时时间（秒），1-900 */
    Timeout?: number;
    /** 函数运行时内存大小（MB），可选 64、128-3072（128为阶梯） */
    MemorySize?: number;
    /** 是否自动安装依赖 */
    InstallDependency?: boolean;
    /** 忽略的文件模式（仅 cwd 方式有效，SCF 类型） */
    Ignore?: string | string[];
}
/**
 * 更新 SCF Agent 的参数
 */
export interface IUpdateScfAgentParams {
    /** Agent ID */
    AgentId: string;
    /** 代码目录路径（与 ZipFile 二选一） */
    cwd?: string;
    /** Base64 编码的 ZIP 文件内容（与 cwd 二选一） */
    ZipFile?: string;
    /** 环境变量 */
    envVariables?: Record<string, string>;
    /** 运行时版本 */
    Runtime?: RuntimeVersion;
    /** 函数超时时间（秒），1-900 */
    Timeout?: number;
    /** 函数运行时内存大小（MB），可选 64、128-3072（128为阶梯） */
    MemorySize?: number;
    /** 是否自动安装依赖 */
    InstallDependency?: boolean;
    /** 忽略的文件模式（仅 cwd 方式有效） */
    Ignore?: string | string[];
}
/**
 * 更新 SCF Agent 的返回结果
 */
export interface IUpdateScfAgentResponse {
    /** 请求 ID */
    RequestId: string;
    /** 总耗时（毫秒） */
    elapsedTime: number;
    /** 结果消息 */
    message: string;
    /** 详细步骤信息 */
    details: string[];
}
/**
 * 更新 TCBR Agent 的参数
 */
export interface IUpdateTcbrAgentParams {
    /** Agent ID */
    AgentId: string;
    /** 代码目录路径（与 ImageUrl 二选一） */
    cwd?: string;
    /** Docker 镜像 URL */
    ImageUrl?: string;
    /** 环境变量 */
    envVariables?: Record<string, string>;
    /** 是否安装依赖，默认 true（仅代码包部署时有效） */
    InstallDependency?: boolean;
    /** CPU 规格（核），如 0.25、0.5、1、2 */
    Cpu?: number;
    /** 内存规格（GB），如 0.5、1、2、4 */
    Mem?: number;
    /** 最小副本数 */
    MinNum?: number;
    /** 最大副本数 */
    MaxNum?: number;
    /** 服务端口 */
    Port?: number;
    /** 延迟检测时间（秒） */
    InitialDelaySeconds?: number;
    /** 日志采集路径，如 "stdout" */
    CustomLogs?: string;
}
/**
 * 获取上传信息的参数
 */
export interface IDescribeCloudBaseBuildServiceParams {
    /** 服务名（即 AgentId） */
    ServiceName: string;
    /** build 类型 */
    CIBusiness?: 'cloudbaserun' | 'framework-ci';
    /** 服务版本 */
    ServiceVersion?: string;
    /** 文件后缀 */
    Suffix?: string;
}
/**
 * 上传信息响应
 */
export interface IDescribeCloudBaseBuildServiceResponse {
    /** 上传 URL */
    UploadUrl: string;
    /** 上传请求头 */
    UploadHeaders: Array<{
        Key: string;
        Value: string;
    }>;
    /** 包名 */
    PackageName: string;
    /** 包版本 */
    PackageVersion: string;
    /** 下载链接 */
    DownloadUrl?: string;
    /** 下载链接是否过期 */
    OutDate?: boolean;
    /** 请求 ID */
    RequestId: string;
}
/**
 * 创建 Agent 响应
 */
export interface ICreateAgentResponse {
    /** Agent ID */
    AgentId: string;
    /** 请求 ID */
    RequestId: string;
}
/**
 * 通用操作响应
 */
export interface ICommonResponse {
    /** 请求 ID */
    RequestId: string;
}
/**
 * 删除 Agent 响应
 */
export interface IDeleteAgentResponse {
    /** 请求 ID */
    RequestId: string;
    /** Agent 记录是否删除成功 */
    AgentDeleted: boolean;
    /** 底层资源删除结果，无底层资源时为 undefined */
    ResourceResult?: {
        /** 资源类型 */
        Type: 'scf' | 'tcbr';
        /** 资源名称 */
        Name: string;
        /** 是否删除成功 */
        Deleted: boolean;
        /** 删除失败时的错误信息 */
        Error?: string;
        /** 删除失败时的清理提示 */
        CleanupHint?: string;
    };
}
/**
 * 获取 Agent 日志的参数
 */
export interface IGetAgentLogsParams {
    /** Agent ID */
    AgentId: string;
    /** 偏移量，默认 0 */
    offset?: number;
    /** 返回数量，默认 10 */
    limit?: number;
    /** 开始时间，如 "2024-01-01 00:00:00" */
    startTime?: string;
    /** 结束时间，如 "2024-01-01 23:59:59" */
    endTime?: string;
    /** 按 RequestId 筛选（仅 SCF Agent） */
    requestId?: string;
}
/**
 * @deprecated 请使用 ICreateTcbrAgentByCodeParams
 * 创建函数型 Agent 的参数（旧版）
 */
export interface ICreateFunctionAgentParams {
    /**
     * 智能体名称
     * @example "hello"
     */
    Name: string;
    /**
     * 智能体ID
     * @example "ibot-aaa-bbb"
     */
    BotId: string;
    /**
     * 智能体简介
     * @example "这是一个智能体"
     */
    Introduction?: string;
    /**
     * 智能体头像
     * @example "https://picsum.photos/200"
     */
    Avatar?: string;
}
