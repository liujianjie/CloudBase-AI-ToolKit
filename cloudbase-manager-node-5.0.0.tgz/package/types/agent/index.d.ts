import { Environment } from '../environment';
import { ICreateFunctionAgentParams, ICreateAgentParams, ICreateTcbrAgentByImageParams, ICreateTcbrAgentByPackageParams, ICreateTcbrAgentByCodeParams, IDescribeAgentListParams, IDescribeAgentListResponse, IDescribeAgentResponse, IDeleteAgentParams, IDescribeCloudBaseBuildServiceParams, IDescribeCloudBaseBuildServiceResponse, ICreateAgentResponse, IDeleteAgentResponse, ICommonResponse, IUpdateAgentParams, IUpdateScfAgentParams, IUpdateScfAgentResponse, IUpdateTcbrAgentParams, IGetAgentLogsParams } from './type';
/**
 * Agent 管理类
 * 支持三种部署方式：
 * - SCF 云函数：轻量级、按需计费
 * - TCBR 云托管-镜像：容器化部署
 * - TCBR 云托管-代码包：源码部署
 */
export declare class AgentService {
    private environment;
    private tcbService;
    constructor(environment: Environment);
    /**
     * 创建 Agent
     * 支持两种方式：
     * 1. 传入 cwd 代码目录，自动打包上传
     * 2. 传入 ZipFile / CosBucketRegion + TempCosObjectName，直接上传
     * @param params 创建参数
     * @returns Agent 创建结果
     */
    createAgent(params: ICreateAgentParams): Promise<ICreateAgentResponse>;
    /**
     * 查询 Agent 列表
     * @param params 查询参数
     * @returns Agent 列表
     */
    describeAgentList(params?: IDescribeAgentListParams): Promise<IDescribeAgentListResponse>;
    /**
     * 查询单个 Agent 详情（包含可用状态）
     * @param agentId Agent ID
     * @returns Agent 详情，IsReady 表示是否可用
     * @example
     * ```typescript
     * const result = await agentService.describeAgent('agent-xxx')
     * if (result.IsReady) {
     *     console.log('Agent 已就绪，可以调用')
     * } else {
     *     console.log('Agent 不可用:', result.NotReadyReason)
     * }
     * ```
     */
    describeAgent(agentId: string): Promise<IDescribeAgentResponse>;
    /**
     * 删除 Agent
     * 先删除 Agent 记录，再尝试删除底层的云函数或云托管服务
     * @param params 删除参数
     * @returns 操作结果，包含 Agent 和底层资源的删除状态
     */
    deleteAgent(params: IDeleteAgentParams): Promise<IDeleteAgentResponse>;
    /**
     * 更新 Agent（自动判断类型）
     * 先查询 Agent 类型，然后调用对应的更新方法
     * @param params 更新参数
     * @returns 操作结果
     */
    updateAgent(params: IUpdateAgentParams): Promise<IUpdateScfAgentResponse>;
    /**
     * 更新 SCF Agent（云函数）
     * 支持两种方式：本地代码目录、ZIP 文件
     * @param params 更新参数
     * @returns 更新结果，包含耗时信息
     */
    updateScfAgent(params: IUpdateScfAgentParams): Promise<IUpdateScfAgentResponse>;
    /**
     * 获取 Agent 调用日志（自动判断类型）
     * @param params 查询参数
     * @returns 日志结果，根据 Agent 类型返回不同结构：
     *   - SCF: IFunctionLogDetailRes[]
     *   - TCBR: ISearchClsLogResponse
     * @example
     * ```typescript
     * const logs = await agentService.getAgentLogs({
     *     AgentId: 'agent-xxx',
     *     limit: 20,
     *     startTime: '2025-01-01 00:00:00',
     *     endTime: '2025-01-01 23:59:59'
     * })
     * ```
     */
    getAgentLogs(params: IGetAgentLogsParams): Promise<any>;
    /**
     * 通过镜像创建 TCBR Agent
     * @internal 暂不对外暴露，后续版本开放
     * @param params 创建参数
     * @returns Agent 创建结果
     */
    createTcbrAgentByImage(params: ICreateTcbrAgentByImageParams): Promise<ICreateAgentResponse>;
    /**
     * 获取代码包上传信息
     * @internal 暂不对外暴露，后续版本开放
     * @param params 查询参数
     * @returns 上传信息
     */
    describeCloudBaseBuildService(params: IDescribeCloudBaseBuildServiceParams): Promise<IDescribeCloudBaseBuildServiceResponse>;
    /**
     * 通过代码包信息创建 TCBR Agent（已上传代码包）
     * @internal 暂不对外暴露，后续版本开放
     * @param params 创建参数
     * @returns Agent 创建结果
     */
    createTcbrAgentByPackage(params: ICreateTcbrAgentByPackageParams): Promise<ICreateAgentResponse>;
    /**
     * 通过本地代码创建 TCBR Agent（自动打包上传）
     * @internal 暂不对外暴露，后续版本开放
     * @param cwd 代码目录，默认当前工作目录
     * @param params 创建参数
     * @returns Agent 创建结果
     */
    createTcbrAgentByCode(cwd: string, params: ICreateTcbrAgentByCodeParams): Promise<ICreateAgentResponse>;
    /**
     * 更新 TCBR Agent（云托管）
     * 支持两种方式：本地代码目录、镜像
     * @internal 暂不对外暴露，后续版本开放
     * @param params 更新参数
     * @returns 操作结果
     */
    updateTcbrAgent(params: IUpdateTcbrAgentParams): Promise<ICommonResponse>;
    /**
     * @deprecated 请使用 createTcbrAgentByCode
     * 创建函数型 Agent（旧版）
     * @param cwd 工作目录
     * @param agentInfo Agent 信息
     * @returns Agent 创建结果
     */
    createFunctionAgent(cwd: string, agentInfo: ICreateFunctionAgentParams): Promise<{
        BotId: string;
        RequestId: string;
    }>;
}
