/**
 * 单个 module 的查询 schema 描述
 */
export interface ClsModuleQuerySchema {
    /** module 中文名 */
    label: string;
    /** 可用的 eventType（没有则为 never） */
    eventType: string;
    /** 可用的 logType（没有则为 never） */
    logType: string;
}
/**
 * 各 module 的完整查询 schema 映射
 *
 * 用法示例：
 * ```ts
 * // 获取某个 module 下可用的 eventType
 * type DbEvents = ClsModuleSchema['database']['eventType']   // 'MongoSlowQuery'
 * type RdbEvents = ClsModuleSchema['rdb']['eventType']        // 'MysqlFreeze' | 'MysqlRecover' | 'MysqlSlowQuery'
 * type AppEvents = ClsModuleSchema['app']['eventType']        // 'AppProdPub' | 'AppProdDel'
 * type LlmLogType = ClsModuleSchema['llm']['logType']         // 'llm-tracelog'
 *
 * // 获取所有 module 名
 * type Modules = ClsLogModule                                  // 'database' | 'rdb' | 'model' | ...
 * ```
 *
 * 查询语句示例（CLS 语法）：
 * - 查询云数据库[文档型]：`module:database`
 * - 查询文档型慢查询：`module:database AND eventType:MongoSlowQuery`
 * - 查询云数据库[SQL型]：`module:rdb`
 * - 查询SQL型事件：`module:rdb AND eventType:(MysqlFreeze OR MysqlRecover OR MysqlSlowQuery)`
 * - 查询审批流：`module:workflow`
 * - 查询数据模型：`module:model`
 * - 查询用户权限：`module:auth`
 * - 查询大模型：`module:llm AND logType:llm-tracelog`
 * - 查询网关服务调用：`logType:accesslog`
 * - 查询应用发布/删除：`module:app AND eventType:(AppProdPub OR AppProdDel)`
 */
export interface ClsModuleSchema {
    /** 云数据库（文档型/MongoDB） */
    database: {
        label: '云数据库(文档型)';
        /** MongoSlowQuery: 文档型数据库慢查询 */
        eventType: 'MongoSlowQuery';
        logType: never;
    };
    /** 云数据库（SQL型/MySQL） */
    rdb: {
        label: '云数据库(SQL型)';
        /** MysqlFreeze: 数据库冻结 | MysqlRecover: 数据库恢复 | MysqlSlowQuery: 数据库慢查询 */
        eventType: 'MysqlFreeze' | 'MysqlRecover' | 'MysqlSlowQuery';
        logType: never;
    };
    /** 数据模型 */
    model: {
        label: '数据模型';
        eventType: never;
        logType: never;
    };
    /** 审批流 */
    workflow: {
        label: '审批流';
        eventType: never;
        logType: never;
    };
    /** 用户权限 */
    auth: {
        label: '用户权限';
        eventType: never;
        logType: never;
    };
    /** 大模型 */
    llm: {
        label: '大模型';
        eventType: never;
        /** llm-tracelog: 大模型追踪日志 */
        logType: 'llm-tracelog';
    };
    /** 应用 */
    app: {
        label: '应用';
        /** AppProdPub: 应用发布 | AppProdDel: 应用删除 */
        eventType: 'AppProdPub' | 'AppProdDel';
        logType: never;
    };
}
/** CLS 日志模块 */
export type ClsLogModule = keyof ClsModuleSchema;
/** CLS 日志事件类型（所有 module 的 eventType 联合） */
export type ClsEventType = ClsModuleSchema[ClsLogModule]['eventType'];
/** CLS 日志类型 */
export type ClsLogType = ClsModuleSchema[ClsLogModule]['logType'] | 'accesslog';
/** 获取指定 module 的 eventType */
export type EventTypeOf<M extends ClsLogModule> = ClsModuleSchema[M]['eventType'];
/** 获取指定 module 的 logType */
export type LogTypeOf<M extends ClsLogModule> = ClsModuleSchema[M]['logType'];
/**
 * CLS 日志搜索基础参数
 */
export interface ISearchClsLogBaseParams {
    /** 查询起始时间，格式 'YYYY-MM-DD HH:mm:ss' */
    StartTime: string;
    /** 查询结束时间，格式 'YYYY-MM-DD HH:mm:ss' */
    EndTime: string;
    /** 单次返回条数，最大 100 */
    Limit: number;
    /** 分页游标，首次为空，后续透传上次返回的 Context */
    Context?: string;
    /** 排序方式：'asc' 升序 / 'desc' 降序（默认 desc） */
    Sort?: 'asc' | 'desc';
    /** 是否使用 Lucene 语法（默认 false） */
    UseLucene?: boolean;
    /**
     * 指定调用的后端服务（默认 'tcb'）
     * - 'tcb': 云函数、数据库等日志（默认）
     * - 'tcbr': 云托管日志
     */
    service?: 'tcb' | 'tcbr';
}
/**
 * CLS 日志搜索参数
 */
export interface ISearchClsLogParams extends ISearchClsLogBaseParams {
    /** CLS 检索分析语句（支持 `| select ...` SQL 分析） */
    queryString: string;
}
/**
 * CLS 日志对象
 */
export interface IClsLogObject {
    /** 日志所属的 Topic ID */
    TopicId: string;
    /** Topic 名称 */
    TopicName: string;
    /** 日志时间 */
    Timestamp: string;
    /** 日志内容（JSON 字符串，需 JSON.parse） */
    Content: string;
    /** 采集路径 */
    FileName: string;
    /** 日志来源设备 */
    Source: string;
}
/**
 * CLS 日志搜索响应
 */
export interface ISearchClsLogResponse {
    /** 日志结果 */
    LogResults: {
        /** 分页游标，用于获取下一页 */
        Context: string;
        /** 是否已返回全部结果 */
        ListOver: boolean;
        /** 日志列表（纯检索模式的结果） */
        Results: IClsLogObject[];
        /**
         * SQL 分析结果（当 QueryString 包含 `| select ...` 管道时返回）
         *
         * 每个元素是一个 JSON 字符串，需 JSON.parse 解析
         * 纯检索模式（无 `|` 管道）时为空数组
         */
        AnalysisRecords?: string[];
    };
    /** 请求 ID */
    RequestId: string;
}
/**
 * ClsModuleSchema 的运行时版本，用于动态生成查询条件 / MCP tool description
 *
 * - key 与 ClsLogModule 类型保持同步
 * - eventTypes / logTypes 为字符串数组，空数组表示该维度不可过滤
 */
export declare const CLS_MODULE_SCHEMA: Record<ClsLogModule, {
    label: string;
    eventTypes: string[];
    logTypes: string[];
}>;
