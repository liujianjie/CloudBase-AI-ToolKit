import { Environment } from '../environment';
import { ISearchClsLogParams, ISearchClsLogResponse } from './types';
export * from './types';
export interface ICreateEnvResourceResponse {
    RequestId: string;
}
export interface ILogServiceEntry {
    LogsetId?: string;
    TopicId?: string;
    TopicName?: string;
    Region?: string;
}
/**
 * 纯函数：根据 DescribeEnvs 返回的 LogServices 列表判断日志服务是否已开通。
 * 已开通条件：至少一个条目有有效的 TopicId。
 */
export declare function isLogServiceEnabled(logServices?: ILogServiceEntry[]): boolean;
export declare class LogService {
    private envId;
    private cloudService;
    private tcbrService;
    constructor(environment: Environment);
    /**
     * 检查当前环境的日志服务是否已开通
     *
     * 通过 DescribeEnvs 接口获取环境信息，判断 LogServices 字段中是否包含有效的
     * 日志主题（TopicId 不为空）。
     *
     * @returns true 表示已开通，false 表示未开通或开通中
     */
    checkLogServiceEnabled(): Promise<boolean>;
    /**
     * 开通环境日志服务（异步操作）
     *
     * 调用 CreateEnvResource 接口开通日志资源。
     * 注意：接口调用成功不代表日志资源立即可用，需通过 checkLogServiceEnabled() 轮询确认。
     *
     * @returns 请求 ID
     */
    createLogService(): Promise<ICreateEnvResourceResponse>;
    /**
     * 搜索 CLS 日志
     *
     * @param params 查询参数，通过 queryString 使用 CLS 原生检索分析语法
     * @returns 日志搜索结果
     *
     * @remarks
     * - 纯检索结果在 `LogResults.Results` 中
     * - SQL 分析结果（queryString 含 `| select ...`）在 `LogResults.AnalysisRecords` 中
     * - 详细的 QueryString 语法参考见 README.md
     */
    searchClsLog(params: ISearchClsLogParams): Promise<ISearchClsLogResponse>;
}
