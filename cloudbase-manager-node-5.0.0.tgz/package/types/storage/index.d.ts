import { Environment } from '../environment';
import { IUploadMetadata, IListFileInfo, IFileInfo, ITempUrlInfo, IResponseInfo } from '../interfaces';
export interface IProgressData {
    loaded: number;
    total: number;
    speed: number;
    percent: number;
}
export interface IOptions {
    onProgress?: OnProgress;
    onFileFinish?: OnFileFinish;
    ignore?: string | string[];
    fileId?: boolean;
    parallel?: number;
}
export interface IFileOptions extends IOptions {
    localPath: string;
    cloudPath?: string;
    parallel?: number;
    retryCount?: number;
    retryInterval?: number;
}
export interface IFilesOptions extends IOptions {
    ignore?: string | string[];
    files: {
        localPath: string;
        cloudPath?: string;
    }[];
    retryCount?: number;
    retryInterval?: number;
}
export interface ICustomOptions {
    bucket: string;
    region: string;
}
export interface IWalkCloudDirOptions {
    prefix: string;
    bucket: string;
    region: string;
    marker?: string;
}
export interface IRoutingRules {
    keyPrefixEquals?: string;
    httpErrorCodeReturnedEquals?: string;
    replaceKeyWith?: string;
    replaceKeyPrefixWith?: string;
}
export interface IBucketWebsiteOptions {
    indexDocument: string;
    errorDocument?: string;
    routingRules?: Array<IRoutingRules>;
    region: string;
    bucket: string;
}
export interface IGetBucketOpions {
    bucket?: string;
    region?: string;
    prefix?: string;
    marker?: string;
    maxKeys?: number;
}
export type AclType = 'READONLY' | 'PRIVATE' | 'ADMINWRITE' | 'ADMINONLY' | 'CUSTOM';
export interface IStorageAclRule {
    /** 读权限规则，true 表示所有用户可读，字符串表示自定义规则表达式 */
    read: boolean | string;
    /** 写权限规则，true 表示所有用户可写，字符串表示自定义规则表达式 */
    write: boolean | string;
}
/** 复制文件选项 */
export interface ICopyOptions {
    /** 源路径（云端路径，如 images/a.jpg） */
    sourcePath: string;
    /** 目标路径（云端路径，如 backup/a.jpg） */
    destPath: string;
    /** 是否强制覆盖已存在的文件 */
    force?: boolean;
    /** 是否跳过已存在的文件 */
    skipExisting?: boolean;
}
/** 复制目录选项 */
export interface ICopyDirectoryOptions extends ICopyOptions {
    /** 包含模式（glob 格式） */
    include?: string | string[];
    /** 排除模式（glob 格式） */
    exclude?: string | string[];
    /** 并发数，默认 20 */
    parallel?: number;
    /** 进度回调 */
    onProgress?: (info: ICopyProgress) => void;
}
/** 复制进度信息 */
export interface ICopyProgress {
    /** 已复制数量 */
    copied: number;
    /** 已跳过数量 */
    skipped: number;
    /** 总数量 */
    total: number;
    /** 当前正在处理的文件 */
    currentFile: string;
}
/** 复制结果状态 */
export type CopyStatus = 'copied' | 'skipped' | 'failed';
/** 复制结果 */
export interface ICopyResult {
    /** 是否成功 */
    success: boolean;
    /** 源路径 */
    sourcePath: string;
    /** 目标路径 */
    destPath: string;
    /** 文件大小 (bytes) */
    size?: number;
    /** 复制状态 */
    status: CopyStatus;
    /** 失败时的错误信息 */
    error?: string;
}
/** 搜索文件选项 */
export interface ISearchOptions {
    /** 搜索模式（glob 或正则表达式） */
    pattern: string;
    /** 搜索目录路径（不指定则搜索根目录） */
    path?: string;
    /** 是否为正则表达式 */
    isRegex?: boolean;
    /** 文件类型过滤（如 jpg, png） */
    fileType?: string;
    /** 限制数量，默认 100 */
    limit?: number;
    /** 是否包含详细信息 */
    includeDetails?: boolean;
}
/** 搜索结果 */
export interface ISearchResult {
    /** 文件路径（云端路径） */
    key: string;
    /** 类型：file 或 directory */
    type: 'file' | 'directory';
    /** 文件大小 (bytes)，仅文件有效 */
    size?: number;
    /** 最后修改时间 (ISO 格式)，仅文件有效 */
    lastModified?: string;
}
type OnProgress = (progressData: IProgressData) => void;
type OnFileFinish = (error: Error, res: any, fileData: any) => void;
export declare class StorageService {
    private environment;
    private tcbService;
    constructor(environment: Environment);
    /**
     * 上传文件
     * localPath 为文件夹时，会尝试在文件夹中寻找 cloudPath 中的文件名
     * @param {string} localPath 本地文件的绝对路径
     * @param {string} cloudPath 云端文件路径，如 img/test.png
     * @returns {Promise<any>}
     */
    uploadFile(options: IFileOptions): Promise<any>;
    /**
     * 批量上传文件，默认并发 5
     * @param options
     */
    uploadFiles(options: IFilesOptions): Promise<void>;
    /**
     * 上传文件，支持自定义 Bucket 和 Region
     * @param {string} localPath
     * @param {string} cloudPath
     * @param {string} bucket
     * @param {string} region
     */
    uploadFileCustom(options: IFileOptions & ICustomOptions): Promise<any>;
    /**
     * 上传文件夹
     * @param {string} localPath 本地文件夹路径
     * @param {string} cloudPath 云端文件夹
     * @param {number} parallel 并发量
     * @param {number} retryCount 重试次数
     * @param {number} retryInterval 重试时间间隔(毫秒)
     * @param {(string | string[])} ignore
     * @param {(string | string[])} ignore
     * @returns {Promise<void>}
     */
    uploadDirectory(options: IFileOptions): Promise<void>;
    /**
     * 上传文件夹，支持自定义 Region 和 Bucket
     * @param {string} localPath
     * @param {string} cloudPath
     * @param {number} parallel
     * @param {number} retryCount
     * @param {number} retryInterval
     * @param {string} bucket
     * @param {string} region
     * @param {IOptions} options
     * @returns {Promise<void>}
     */
    uploadDirectoryCustom(options: IFileOptions & ICustomOptions): Promise<void>;
    /**
     * 批量上传文件
     * @param options
     */
    uploadFilesCustom(options: IFilesOptions & ICustomOptions): Promise<any>;
    /**
     * 创建一个空的文件夹
     * @param {string} cloudPath
     */
    createCloudDirectroy(cloudPath: string): Promise<void>;
    /**
     * 创建一个空的文件夹，支持自定义 Region 和 Bucket
     * @param {string} cloudPath
     * @param {string} bucket
     * @param {string} region
     */
    createCloudDirectroyCustom(options: ICustomOptions & {
        cloudPath: string;
    }): Promise<void>;
    /**
     * 下载文件
     * @param {string} cloudPath 云端文件路径
     * @param {string} localPath 文件本地存储路径，文件需指定文件名称
     * @returns {Promise<NodeJS.ReadableStream>}
     */
    downloadFile(options: {
        cloudPath: string;
        localPath?: string;
    }): Promise<NodeJS.ReadableStream | string>;
    /**
     * 下载文件夹
     * @param {string} cloudPath 云端文件路径
     * @param {string} localPath 本地文件夹存储路径
     * @returns {Promise<(NodeJS.ReadableStream | string)[]>}
     */
    downloadDirectory(options: {
        cloudPath: string;
        localPath?: string;
        parallel?: number;
    }): Promise<(NodeJS.ReadableStream | string)[]>;
    /**
     * 列出文件夹下的文件
     * @link https://cloud.tencent.com/document/product/436/7734
     * @param {string} cloudPath 云端文件夹，如果为空字符串，则表示根目录
     * @returns {Promise<ListFileInfo[]>}
     */
    listDirectoryFiles(cloudPath: string): Promise<IListFileInfo[]>;
    /**
     * 获取文件临时下载链接
     * @param {((string | ITempUrlInfo)[])} fileList 文件路径或文件信息数组
     * @returns {Promise<{ fileId: string; url: string }[]>}
     */
    getTemporaryUrl(fileList: (string | ITempUrlInfo)[]): Promise<{
        fileId: string;
        url: string;
    }[]>;
    /**
     * 删除文件
     * @param {string[]} cloudPathList 云端文件路径数组
     * @returns {Promise<void>}
     */
    deleteFile(cloudPathList: string[]): Promise<void>;
    /**
     * 删除文件，可以指定 Bucket 和 Region
     * @param {string[]} cloudPathList
     * @param {string} bucket
     * @param {string} region
     * @returns {Promise<void>}
     */
    deleteFileCustom(cloudPathList: string[], bucket: string, region: string): Promise<void>;
    /**
     * 获取文件信息
     * @param {string} cloudPath 云端文件路径
     * @returns {Promise<FileInfo>}
     */
    getFileInfo(cloudPath: string): Promise<IFileInfo>;
    /**
     * 删除文件夹
     * @param {string} cloudPath 云端文件夹路径
     * @returns {Promise<void>}
     */
    deleteDirectory(cloudPath: string): Promise<{
        Deleted: {
            Key: string;
        }[];
        Error: Object[];
    }>;
    /**
     * 删除文件，可以指定 bucket 和 region
     * @param {string} cloudPath
     * @param {string} bucket
     * @param {string} region
     * @returns {Promise<void>}
     */
    deleteDirectoryCustom(options: {
        cloudPath: string;
    } & ICustomOptions): Promise<{
        Deleted: {
            Key: string;
        }[];
        Error: Object[];
    }>;
    /**
     * 获取文件存储权限
     * READONLY：所有用户可读，仅创建者和管理员可写
     * PRIVATE：仅创建者及管理员可读写
     * ADMINWRITE：所有用户可读，仅管理员可写
     * ADMINONLY：仅管理员可读写
     * CUSTOM：自定义安全规则
     *
     * @param options.withRule 是否返回自定义安全规则，默认 false 以保持向后兼容
     * @returns 不传参数时返回 AclType（向后兼容），传入 { withRule: true } 时返回 { acl: AclType, rule?: IStorageAclRule }
     *
     * @example
     * // 向后兼容的简单用法（返回 AclType）
     * const acl = await storage.getStorageAcl()
     * if (acl === 'READONLY') { ... }
     *
     * // 获取自定义安全规则（返回对象）
     * const result = await storage.getStorageAcl({ withRule: true })
     * console.log(result.acl, result.rule)
     */
    getStorageAcl(): Promise<AclType>;
    getStorageAcl(options: {
        withRule: true;
    }): Promise<{
        acl: AclType;
        rule?: IStorageAclRule;
    }>;
    /**
     * 设置文件存储权限
     * READONLY：所有用户可读，仅创建者和管理员可写
     * PRIVATE：仅创建者及管理员可读写
     * ADMINWRITE：所有用户可读，仅管理员可写
     * ADMINONLY：仅管理员可读写
     * CUSTOM：自定义安全规则（需要传入 rule 参数）
     * @param {AclType} acl 权限类型
     * @param {IStorageAclRule} [rule] 自定义安全规则，当 acl 为 CUSTOM 时必填
     * @returns
     * @example
     * // 设置简易权限
     * await storage.setStorageAcl('READONLY')
     *
     * // 设置自定义安全规则
     * await storage.setStorageAcl('CUSTOM', {
     *     read: true,
     *     write: 'resource.openid == auth.uid'
     * })
     */
    setStorageAcl(acl: AclType, rule?: IStorageAclRule): Promise<IResponseInfo>;
    /**
     * 遍历云端文件夹
     * @param {string} prefix
     * @param {string} [marker] 路径开始标志
     * @returns {Promise<IListFileInfo[]>}
     */
    walkCloudDir(prefix: string, marker?: string): Promise<IListFileInfo[]>;
    /**
     * 遍历云端文件夹，支持自定义 Bucket 和 Region
     * @param {string} prefix
     * @param {string} [marker]
     * @param {string} bucket
     * @param {string} region
     * @returns {Promise<IListFileInfo[]>}
     */
    walkCloudDirCustom(options: IWalkCloudDirOptions): Promise<IListFileInfo[]>;
    /**
     * 列出指定目录下的文件和子目录（不递归，只列当前层）
     * 使用 COS Delimiter 参数实现
     * @param {string} dirPath 目录路径，空字符串表示根目录
     * @returns {Promise<{ files: IListFileInfo[], directories: string[] }>}
     */
    listCurrentDirectory(dirPath?: string): Promise<{
        files: IListFileInfo[];
        directories: string[];
    }>;
    /**
     * 遍历本地文件夹
     * 忽略不包含 dir 路径，即如果 ignore 匹配 dir，dir 也不会被忽略
     * @private
     * @param {string} dir
     * @param {(string | string[])} [ignore]
     * @returns
     */
    walkLocalDir(dir: string, ignore?: string | string[]): Promise<string[]>;
    /**
     * 获取文件上传链接属性
     */
    getUploadMetadata(path: string): Promise<IUploadMetadata>;
    /**
     * 获取静态网站配置
     */
    getWebsiteConfig(options: {
        bucket: string;
        region: string;
    }): Promise<any>;
    /**
     * 配置文档
     */
    putBucketWebsite(options: IBucketWebsiteOptions): Promise<any>;
    /**
     * 查询object列表
     * @param {IGetBucketOpions} options
     * @memberof StorageService
     */
    getBucket(options: IGetBucketOpions): Promise<any>;
    /**
     * 复制单个文件
     * @param options.sourcePath 源文件路径（云端路径，如 images/a.jpg）
     * @param options.destPath 目标文件路径（云端路径，如 backup/a.jpg）
     * @param options.force 是否强制覆盖
     * @param options.skipExisting 是否跳过已存在的文件
     * @returns 复制结果
     */
    copyFile(options: ICopyOptions): Promise<ICopyResult>;
    /**
     * 复制目录
     * 遍历源目录下的所有文件，并行复制到目标目录
     * @param options.sourcePath 源目录路径
     * @param options.destPath 目标目录路径
     * @param options.include 包含模式（glob 格式）
     * @param options.exclude 排除模式（glob 格式）
     * @param options.force 是否强制覆盖
     * @param options.skipExisting 是否跳过已存在的文件
     * @param options.parallel 并发数，默认 20
     * @param options.onProgress 进度回调
     * @returns 复制结果数组
     */
    copyDirectory(options: ICopyDirectoryOptions): Promise<ICopyResult[]>;
    /**
     * 移动文件（复制后删除源文件）
     * 注意：移动操作是「复制 + 删除」的两步操作，如果删除失败，文件会同时存在于源和目标位置
     * @param options 与 copyFile 相同的选项
     * @returns 移动结果，如果删除源文件失败会在 error 字段说明
     */
    moveFile(options: ICopyOptions): Promise<ICopyResult>;
    /**
     * 移动目录（复制后删除源目录）
     * 注意：移动操作是「复制 + 删除」的两步操作，如果部分删除失败，文件会同时存在于源和目标位置
     * @param options 与 copyDirectory 相同的选项
     * @returns 移动结果数组，删除失败的文件会在对应结果的 error 字段说明
     */
    moveDirectory(options: ICopyDirectoryOptions): Promise<ICopyResult[]>;
    /**
     * 搜索文件和目录（只搜索当前目录，不递归）
     * @param options.pattern 搜索模式（支持 glob 或正则表达式）
     * @param options.path 搜索目录路径（不指定则搜索根目录）
     * @param options.isRegex 是否为正则表达式模式
     * @param options.fileType 文件类型过滤
     * @param options.limit 限制返回数量，默认 100
     * @param options.includeDetails 是否包含详细信息（大小、修改时间）
     * @returns 搜索结果数组（包含文件和目录）
     */
    searchFiles(options: ISearchOptions): Promise<ISearchResult[]>;
    /**
     * 获取 COS 配置
     */
    private getCos;
    /**
     * 将 cloudPath 转换成 cloudPath/ 形式
     */
    private getCloudKey;
    /**
     * 将 cloudPath 转换成 fileId
     */
    private cloudPathToFileId;
    /**
     * 获取存储桶配置
     */
    private getStorageConfig;
    /**
     * 带重试功能的上传多文件函数
     * @param uploadFiles sdk上传函数
     * @param options sdk上传函数参数
     * @param times 重试次数
     * @param interval 重试时间间隔(毫秒)
     * @param failedFiles 失败文件列表
     * @returns
     */
    private uploadFilesWithRetry;
    /**
     * 拼接路径下载单文件
     * @param file
     * @param cloudDirectoryKey
     * @param resolveLocalPath
     * @returns
     */
    private downloadWithFilePath;
    /**
     * 根据下载结果返回错误列表
     * @param res
     * @returns
     */
    private determineDownLoadResultIsError;
}
export {};
