/** 账号输入信息（用于删除、查询权限等操作） */
export interface IInputAccount {
    /** 账号名称 */
    AccountName: string;
    /** 主机，默认 '%' */
    Host?: string;
}
/** 新建账号信息 */
export interface INewAccount {
    /** 账号名称 */
    AccountName: string;
    /** 账号密码（8-64个字符，包含大小写英文字母、数字和符号） */
    AccountPassword: string;
    /** 允许访问的主机，可以是 IP 或 '%' */
    Host: string;
    /** 账号描述 */
    Description?: string;
    /** 用户最大连接数限制 */
    MaxUserConnections?: number;
}
/** 创建账号请求参数 */
export interface ICreateAccountsOptions {
    /** 新账户列表 */
    Accounts: INewAccount[];
}
/** 删除账号请求参数 */
export interface IDeleteAccountsOptions {
    /** 账号数组 */
    Accounts?: IInputAccount[];
}
/** 查询账号列表请求参数 */
export interface IDescribeAccountsOptions {
    /** 需要过滤的账户列表 */
    AccountNames?: string[];
    /** 需要过滤的主机列表 */
    Hosts?: string[];
    /** 限制量 */
    Limit?: number;
    /** 偏移量 */
    Offset?: number;
    /** 模糊匹配关键字（同时匹配 AccountName 和 Host，支持正则） */
    AccountRegular?: string;
}
/** 账号信息 */
export interface IAccountInfo {
    /** 账号名称 */
    AccountName: string;
    /** 账号描述 */
    Description: string;
    /** 创建时间 */
    CreateTime: string;
    /** 更新时间 */
    UpdateTime: string;
    /** 主机 */
    Host: string;
    /** 最大用户连接数 */
    MaxUserConnections: number;
}
/** 查询账号列表返回结果 */
export interface IDescribeAccountsResult {
    /** 账号列表 */
    AccountSet: IAccountInfo[];
    /** 账号总数 */
    TotalCount: number;
}
/** 修改账号描述请求参数 */
export interface IModifyAccountDescriptionOptions {
    /** 账号名称 */
    AccountName: string;
    /** 新的描述信息 */
    Description: string;
    /** 主机，默认 '%' */
    Host?: string;
}
/** 修改账号主机请求参数 */
export interface IModifyAccountHostOptions {
    /** 账号信息 */
    Account: IInputAccount;
    /** 新主机 */
    NewHost: string;
}
/** 账号参数项 */
export interface IAccountParamItem {
    /** 参数名称 */
    ParamName: string;
    /** 参数值 */
    ParamValue: string;
}
/** 修改账号配置请求参数 */
export interface IModifyAccountParamsOptions {
    /** 账号信息 */
    Account: IInputAccount;
    /** 账号参数列表 */
    AccountParams: IAccountParamItem[];
}
/** 数据库权限 */
export interface IDatabasePrivilege {
    /** 数据库名 */
    Db: string;
    /** 权限列表 */
    Privileges: string[];
}
/** 表权限 */
export interface ITablePrivilege {
    /** 数据库名 */
    Db: string;
    /** 表名 */
    TableName: string;
    /** 权限列表 */
    Privileges: string[];
}
/** 修改账号权限请求参数 */
export interface IModifyAccountPrivilegesOptions {
    /** 账号信息 */
    Account: IInputAccount;
    /** 全局权限 */
    GlobalPrivileges?: string[];
    /** 数据库权限 */
    DatabasePrivileges?: IDatabasePrivilege[];
    /** 表权限 */
    TablePrivileges?: ITablePrivilege[];
}
/** 查询账号已有权限请求参数 */
export interface IDescribeAccountPrivilegesOptions {
    /** 账号名 */
    AccountName: string;
    /** 主机 */
    Host: string;
    /** 数据库名，为 '*' 时忽略 Type/TableName，表示修改用户全局权限 */
    Db: string;
    /** 指定数据库下的对象类型，可选 'table' 或 '*' */
    Type: string;
    /** 当 Type='table' 时，用来指定表名 */
    TableName?: string;
}
/** 查询账号已有权限返回结果 */
export interface IDescribeAccountPrivilegesResult {
    /** 权限列表 */
    Privileges: string[];
}
/** 查询账号所有可授予权限返回结果 */
export interface IDescribeAccountAllGrantPrivilegesResult {
    /** 权限语句 */
    PrivilegeStatements: string[];
    /** 全局权限 */
    GlobalPrivileges: string[];
    /** 数据库权限 */
    DatabasePrivileges: IDatabasePrivilege[];
    /** 表权限 */
    TablePrivileges: ITablePrivilege[];
}
/** 重置账号密码请求参数 */
export interface IResetAccountPasswordOptions {
    /** 账号名称 */
    AccountName: string;
    /** 新密码 */
    AccountPassword: string;
    /** 主机，默认 '%' */
    Host?: string;
}
