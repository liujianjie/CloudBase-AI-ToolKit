import { IResponseInfo } from '../../interfaces';
/** 开通 MySQL 请求参数 */
export interface ICreateMySQLOptions {
    /** Db类型，固定值 MYSQL */
    DbInstanceType: string;
    /** mysql 版本，如 '5.7' */
    MysqlVersion?: string;
    /** vpc Id */
    VpcId?: string;
    /** 子网 ID */
    SubnetId?: string;
    /** 0 区分表名大小写；1 不区分表名大小写(默认) */
    LowerCaseTableNames?: string;
}
/** 开通 MySQL 返回结果 */
export interface ICreateMySQLResult {
    /** 异步任务 ID */
    TaskId: string;
}
/** 开通结果查询返回 */
export interface IDescribeCreateMySQLResult {
    /** 状态：notexist 未开通，success 开通成功 */
    Status: string;
    /** 失败原因 */
    FailReason: string | null;
    /** 冻结状态 */
    FreezeStatus: boolean;
}
/** MySQL 集群数据库详情 */
export interface IMySQLDbInfo {
    ClusterStatus: string;
    DbType: string;
    DbVersion: string;
    IsOpenPubNetAccess: boolean;
    MaxCpu: number;
    MinCpu: number;
    ServerlessStatus: string;
    Status: string;
    StorageLimit: number;
    UsedStorage: number;
    WanStatus: string;
}
/** MySQL 集群网络详情 */
export interface IMySQLNetInfo {
    Net: string;
    PrivateNetAddress: string;
    PubNetAddress: string;
    SubnetId: string;
    SubnetName: string;
    VpcId: string;
    VpcName: string;
}
/** MySQL 集群详情 */
export interface IMySQLClusterDetail {
    DbClusterId: string;
    DbInfo: IMySQLDbInfo;
    NetInfo: IMySQLNetInfo;
}
/** 销毁 MySQL 返回结果 */
export interface IDestroyMySQLResult {
    IsSuccess: boolean;
    TaskId: string;
    TaskName: string;
}
/** MySQL 任务状态 */
export interface IMySQLTaskStatus {
    /** 任务状态：SUCCESS / FAILED 等 */
    Status: string;
    /** 状态描述 */
    StatusDesc: string;
}
/** 执行 SQL 请求参数 */
export interface IRunSqlOptions {
    /** 要执行的 SQL 语句 */
    Sql: string;
    /** 数据库连接器实例信息 */
    DbInstance?: Record<string, any>;
    /** 是否只读（true 时仅允许 SELECT/WITH/SHOW/DESCRIBE/DESC/EXPLAIN 开头的 SQL） */
    ReadOnly?: boolean;
}
/** 执行 SQL 返回结果 */
export interface IRunSqlResult extends IResponseInfo {
    /** 查询结果行，每个元素为 JSON 字符串 */
    Items: string[];
    /** 列元数据信息 */
    Infos: string[];
    /** 受影响的行数 */
    RowsAffected: number;
}
/** 开启/关闭外网请求参数 */
export interface IWanOptions {
    /** 实例 ID */
    InstanceId?: string;
    /** 实例组 ID */
    InstanceGroupId?: string;
}
/** 开启/关闭外网返回结果 */
export interface IWanResult {
    /** 任务流 ID */
    FlowId: number;
}
/** 实例组中的实例信息 */
export interface ICynosdbInstance {
    /** 实例 ID */
    InstanceId: string;
    /** 实例名称 */
    InstanceName: string;
    /** 实例状态 */
    Status: string;
    /** 实例类型，如 rw（读写） */
    InstanceType?: string;
    /** 实例角色，如 master */
    InstanceRole?: string;
    [key: string]: any;
}
/** 实例组信息 */
export interface ICynosdbInstanceGroup {
    /** 实例组 ID */
    InstanceGroupId: string;
    /** 集群 ID */
    ClusterId: string;
    /** 实例组状态 */
    Status: string;
    /** 实例组类型（如 ha） */
    Type: string;
    /** 内网 IP */
    Vip: string;
    /** 内网端口 */
    Vport: number;
    /** 外网域名 */
    WanDomain: string;
    /** 外网 IP */
    WanIP: string;
    /** 外网端口 */
    WanPort: number;
    /** 外网状态 */
    WanStatus: string;
    /** 实例列表 */
    InstanceSet: ICynosdbInstance[];
    [key: string]: any;
}
/** 查询实例组返回结果 */
export interface IDescribeClusterInstanceGroupsResult {
    /** 实例组个数 */
    TotalCount: number;
    /** 实例组列表 */
    InstanceGroupInfoList: ICynosdbInstanceGroup[];
}
/** 查询过滤条件（Name 与 Names 二选一，不可同时设置） */
export interface IQueryFilter {
    /** 搜索字段名（单个），如 status、ClusterId 等 */
    Name?: string;
    /** 搜索字段名（数组），如 ['status'] 等 */
    Names?: string[];
    /** 搜索字段的值 */
    Values: string[];
    /** 是否精确匹配 */
    ExactMatch?: boolean;
}
/** 任务信息 */
export interface IBizTaskInfo {
    /** 任务 ID */
    ID: number;
    /** 集群 ID */
    ClusterId: string;
    /** 实例 ID */
    InstanceId: string;
    /** 任务状态 */
    Status: string;
    /** 任务类型 */
    TaskType: string;
    /** 开始时间 */
    StartTime: string;
    /** 结束时间 */
    EndTime: string;
    /** 创建时间 */
    CreateTime: string;
    /** 任务进度 */
    Progress: number;
    [key: string]: any;
}
/** 查询任务列表请求参数 */
export interface IDescribeTasksOptions {
    /** 任务开始时间起始值 */
    StartTimeBegin?: string;
    /** 任务开始时间结束值 */
    StartTimeEnd?: string;
    /** 过滤条件 */
    Filters?: IQueryFilter[];
    /** 查询列表长度 */
    Limit?: number;
    /** 查询列表偏移量 */
    Offset?: number;
}
/** 查询任务列表返回结果 */
export interface IDescribeTasksResult {
    /** 任务列表总条数 */
    TotalCount: number;
    /** 任务列表 */
    TaskList: IBizTaskInfo[];
}
/** 查询实例列表请求参数 */
export interface IDescribeInstancesOptions {
    /** 返回数量，默认为 20，取值范围为 (0,100] */
    Limit?: number;
    /** 记录偏移量，默认值为 0 */
    Offset?: number;
    /** 排序字段：CREATETIME（创建时间）、PERIODENDTIME（过期时间） */
    OrderBy?: string;
    /** 排序类型：ASC（升序）、DESC（降序） */
    OrderByType?: string;
    /** 搜索条件，多个 Filter 之间为逻辑与（AND）关系 */
    Filters?: IQueryFilter[];
    /** 引擎类型，目前支持 MYSQL */
    DbType?: string;
    /** 实例状态：creating / running / isolating / isolated / activating / offlining / offlined */
    Status?: string;
    /** 实例 ID 列表 */
    InstanceIds?: string[];
    /** 集群类型：CYNOSDB（事务集群）、LIBRADB（分析集群）、ALL（全部，缺省默认值） */
    ClusterType?: string;
}
/** 实例信息 */
export interface ICynosdbInstanceDetail {
    /** 用户 Uin */
    Uin?: string;
    /** 用户 AppId */
    AppId?: number;
    /** 集群 ID */
    ClusterId?: string;
    /** 集群名称 */
    ClusterName?: string;
    /** 实例 ID */
    InstanceId?: string;
    /** 实例名称 */
    InstanceName?: string;
    /** 项目 ID */
    ProjectId?: number;
    /** 地域 */
    Region?: string;
    /** 可用区 */
    Zone?: string;
    /** 实例状态 */
    Status?: string;
    /** 实例状态中文描述 */
    StatusDesc?: string;
    /** 数据库模式：NORMAL / SERVERLESS */
    DbMode?: string;
    /** 数据库类型 */
    DbType?: string;
    /** 数据库版本 */
    DbVersion?: string;
    /** Cpu，单位：核 */
    Cpu?: number;
    /** 内存，单位：GB */
    Memory?: number;
    /** 存储量，单位：GB */
    Storage?: number;
    /** 实例类型 */
    InstanceType?: string;
    /** 实例角色 */
    InstanceRole?: string;
    /** 更新时间 */
    UpdateTime?: string;
    /** 创建时间 */
    CreateTime?: string;
    /** 到期时间 */
    PeriodEndTime?: string;
    /** VPC ID */
    VpcId?: string;
    /** 子网 ID */
    SubnetId?: string;
    /** 内网 IP */
    Vip?: string;
    /** 内网端口 */
    Vport?: number;
    /** 付费模式：0（后付费）、1（预付费） */
    PayMode?: number;
    /** 外网域名 */
    WanDomain?: string;
    /** 外网 IP */
    WanIP?: string;
    /** 外网端口 */
    WanPort?: number;
    /** 外网状态 */
    WanStatus?: string;
    /** 续费标志 */
    RenewFlag?: number;
    /** 正在处理的任务 */
    ProcessingTask?: string;
    /** 任务列表 */
    Tasks?: Array<Record<string, any>>;
    /** 资源标签 */
    ResourceTags?: Array<Record<string, any>>;
    /** 实例网络信息 */
    InstanceNetInfo?: Array<Record<string, any>>;
    [key: string]: any;
}
/** 查询实例列表返回结果 */
export interface IDescribeInstancesResult {
    /** 实例个数 */
    TotalCount: number;
    /** 实例列表 */
    InstanceSet: ICynosdbInstanceDetail[];
}
/** 重启实例请求参数 */
export interface IRestartInstanceOptions {
    /** 实例 ID */
    InstanceId: string;
}
/** 重启实例返回结果 */
export interface IRestartInstanceResult {
    /** 异步任务 ID */
    FlowId: number;
}
/** 查询实例详情请求参数 */
export interface IDescribeInstanceDetailOptions {
    /** 实例 ID */
    InstanceId: string;
}
/** 实例详情信息 */
export interface ICynosdbInstanceFullDetail {
    /** 用户 Uin */
    Uin?: string;
    /** 用户 AppId */
    AppId?: number;
    /** 集群 ID */
    ClusterId?: string;
    /** 集群名称 */
    ClusterName?: string;
    /** 实例 ID */
    InstanceId?: string;
    /** 实例名称 */
    InstanceName?: string;
    /** 项目 ID */
    ProjectId?: number;
    /** 地域 */
    Region?: string;
    /** 可用区 */
    Zone?: string;
    /** 实例状态 */
    Status?: string;
    /** 实例状态中文描述 */
    StatusDesc?: string;
    /** 数据库类型 */
    DbType?: string;
    /** 数据库版本 */
    DbVersion?: string;
    /** CPU 核数 */
    Cpu?: number;
    /** 内存（GB） */
    Memory?: number;
    /** 存储量（GB） */
    Storage?: number;
    /** 实例类型，如 rw */
    InstanceType?: string;
    /** 实例角色，如 master */
    InstanceRole?: string;
    /** 更新时间 */
    UpdateTime?: string;
    /** 创建时间 */
    CreateTime?: string;
    /** 到期时间 */
    PeriodEndTime?: string;
    /** VPC ID */
    VpcId?: string;
    /** 子网 ID */
    SubnetId?: string;
    /** 内网 IP */
    Vip?: string;
    /** 内网端口 */
    Vport?: number;
    /** 付费模式：0（后付费）、1（预付费） */
    PayMode?: number;
    /** 外网域名 */
    WanDomain?: string;
    /** 续费标志 */
    RenewFlag?: number;
    /** 最小 CPU（Serverless） */
    MinCpu?: number;
    /** 最大 CPU（Serverless） */
    MaxCpu?: number;
    /** Serverless 状态 */
    ServerlessStatus?: string;
    /** 字符集 */
    Charset?: string;
    /** 网络类型 */
    NetType?: number;
    /** 兼容内核版本 */
    CynosVersion?: string;
    [key: string]: any;
}
/** 查询实例详情返回结果 */
export interface IDescribeInstanceDetailResult {
    /** 实例详情 */
    Detail: ICynosdbInstanceFullDetail;
}
/** Proxy 同步升级参数 */
export interface IUpgradeProxy {
    /** CPU 核数 */
    Cpu?: number;
    /** 内存（MB） */
    Mem?: number;
    /** 重新负载均衡：auto / manual */
    ReloadBalance?: string;
    /** Proxy 节点可用区 */
    ProxyZones?: Array<{
        /** 节点可用区 */
        ProxyNodeZone?: string;
        /** 节点数量 */
        ProxyNodeCount?: number;
    }>;
}
/** 实例变配请求参数 */
export interface IUpgradeInstanceOptions {
    /** 实例 ID */
    InstanceId: string;
    /** 数据库 CPU */
    Cpu: number;
    /** 数据库内存，单位 GB */
    Memory: number;
    /** 升级类型：upgradeImmediate（立即升级）、upgradeInMaintain（在维护时间内升级） */
    UpgradeType: string;
    /** 实例机器类型 */
    DeviceType?: string;
    /** 是否自动选择代金券：1 是，0 否，默认 0 */
    AutoVoucher?: number;
    /** 交易模式：0 下单并支付，1 下单 */
    DealMode?: number;
    /** 升级模式：NormalUpgrade 普通变配，FastUpgrade 极速变配 */
    UpgradeMode?: string;
    /** Proxy 同步升级参数 */
    UpgradeProxy?: IUpgradeProxy;
}
/** 实例变配返回结果 */
export interface IUpgradeInstanceResult {
    /** 冻结流水 ID */
    TranId: string;
    /** 大订单号 */
    BigDealIds: string[];
    /** 订单号 */
    DealNames: string[];
}
/** 查询实例慢查询日志请求参数 */
export interface IDescribeInstanceSlowQueriesOptions {
    /** 实例 ID */
    InstanceId: string;
    /** 事务开始最早时间 */
    StartTime?: string;
    /** 事务开始最晚时间 */
    EndTime?: string;
    /** 限制条数 */
    Limit?: number;
    /** 偏移量 */
    Offset?: number;
    /** 用户名 */
    Username?: string;
    /** 客户端 host */
    Host?: string;
    /** 数据库名 */
    Database?: string;
    /** 排序字段：QueryTime / LockTime / RowsExamined / RowsSent */
    OrderBy?: string;
    /** 排序类型：asc / desc */
    OrderByType?: string;
    /** SQL 语句（用于过滤） */
    SqlText?: string;
}
/** 慢查询记录 */
export interface ISlowQueriesItem {
    /** 时间戳 */
    Timestamp?: number;
    /** SQL 语句 */
    SqlText?: string;
    /** SQL 模板 */
    SqlTemplate?: string;
    /** SQL MD5 */
    SqlMd5?: string;
    /** 数据库名 */
    Database?: string;
    /** 用户名 */
    UserName?: string;
    /** 客户端 Host/IP */
    UserHost?: string;
    /** 查询耗时（秒） */
    QueryTime?: number;
    /** 锁等待时间（秒） */
    LockTime?: number;
    /** 发送的行数 */
    RowsSent?: number;
    /** 扫描的行数 */
    RowsExamined?: number;
    [key: string]: any;
}
/** 查询实例慢查询日志返回结果 */
export interface IDescribeInstanceSlowQueriesResult {
    /** 总条数 */
    TotalCount: number;
    /** 慢查询记录列表 */
    SlowQueries: ISlowQueriesItem[];
}
/** 查询错误日志请求参数 */
export interface IDescribeInstanceErrorLogsOptions {
    /** 实例 ID */
    InstanceId: string;
    /** 日志条数限制 */
    Limit?: number;
    /** 日志条数偏移量 */
    Offset?: number;
    /** 开始时间 */
    StartTime?: string;
    /** 结束时间 */
    EndTime?: string;
    /** 排序字段，支持 Timestamp */
    OrderBy?: string;
    /** 排序类型：ASC / DESC */
    OrderByType?: string;
    /** 日志等级：error / warning / note，支持多个 */
    LogLevels?: string[];
    /** 关键字，支持模糊搜索 */
    KeyWords?: string[];
}
/** 错误日志记录 */
export interface ICynosdbErrorLogItem {
    /** 日志内容 */
    Content?: string;
    /** 日志等级 */
    Level?: string;
    /** 时间戳 */
    Timestamp?: number;
    [key: string]: any;
}
/** 查询错误日志返回结果 */
export interface IDescribeInstanceErrorLogsResult {
    /** 日志总条数 */
    TotalCount: number;
    /** 错误日志列表 */
    ErrorLogs: ICynosdbErrorLogItem[];
}
/** 查询集群数据库列表请求参数 */
export interface IDescribeClusterDatabasesOptions {
    /** 偏移量 */
    Offset?: number;
    /** 返回数量 */
    Limit?: number;
}
/** 查询集群数据库列表返回结果 */
export interface IDescribeClusterDatabasesResult {
    /** 总条数 */
    TotalCount: number;
    /** 偏移量 */
    Offset: number;
    /** 数据库名称列表 */
    Databases: string[];
    /** 返回数量 */
    Limit: number;
}
/** 查询集群数据库表列表请求参数 */
export interface IDescribeClusterDatabaseTablesOptions {
    /** 数据库名 */
    Db: string;
    /** 偏移量 */
    Offset?: number;
    /** 返回数量 */
    Limit?: number;
    /** 数据表类型：view（视图）、base_table（基本表）、all（全部，默认） */
    TableType?: string;
}
/** 查询集群数据库表列表返回结果 */
export interface IDescribeClusterDatabaseTablesResult {
    /** 总条数 */
    TotalCount: number;
    /** 偏移量 */
    Offset: number;
    /** 返回数量 */
    Limit: number;
    /** 数据库表列表 */
    Tables: string[];
}
