/** 数据库表信息（用于备份） */
export interface IDatabaseTables {
    /** 数据库名 */
    Database?: string;
    /** 表名称列表 */
    Tables?: string[];
}
/** 创建备份请求参数 */
export interface ICreateBackupOptions {
    /** 备份类型：logic（逻辑备份）、snapshot（物理备份） */
    BackupType?: string;
    /** 备份的库，只在 BackupType 为 logic 时有效 */
    BackupDatabases?: string[];
    /** 备份的表，只在 BackupType 为 logic 时有效 */
    BackupTables?: IDatabaseTables[];
    /** 备注名 */
    BackupName?: string;
}
/** 创建备份返回结果 */
export interface ICreateBackupResult {
    /** 异步任务流 ID */
    FlowId: number;
}
/** 删除备份请求参数 */
export interface IDeleteBackupOptions {
    /** 备份文件 ID（推荐使用） */
    BackupIds?: number[];
    /** 备份文件 ID（旧版本，不推荐） */
    SnapshotIdList?: number[];
}
/** 修改备份配置请求参数 */
export interface IModifyBackupConfigOptions {
    /** 全备开始时间，范围 [0-24*3600]，如 0:00=0, 1:00=3600, 2:00=7200 */
    BackupTimeBeg?: number;
    /** 全备结束时间，范围 [0-24*3600] */
    BackupTimeEnd?: number;
    /** 保留备份时长（秒），超过该时间将被清理，如七天=604800 */
    ReserveDuration?: number;
    /** 备份频率，长度为7的数组，对应周一到周日，full-全量，increment-增量 */
    BackupFreq?: string[];
    /** 备份类型 */
    BackupType?: string;
}
/** 查询备份列表请求参数 */
export interface IDescribeBackupListOptions {
    /** 返回数量，取值范围 (0,100] */
    Limit?: number;
    /** 记录偏移量 */
    Offset?: number;
    /** 数据库类型，取值 MYSQL */
    DbType?: string;
    /** 备份 ID 列表 */
    BackupIds?: number[];
    /** 备份类型：snapshot（快照备份）、logic（逻辑备份） */
    BackupType?: string;
    /** 备份方式：auto（自动备份）、manual（手动备份） */
    BackupMethod?: string;
    /** 快照类型：full（全量）、increment（增量） */
    SnapShotType?: string;
    /** 备份开始时间 */
    StartTime?: string;
    /** 备份结束时间 */
    EndTime?: string;
    /** 备份文件名，支持模糊查询 */
    FileNames?: string[];
    /** 备份备注名，支持模糊查询 */
    BackupNames?: string[];
    /** 快照备份 ID 列表 */
    SnapshotIdList?: number[];
    /** 备份地域 */
    BackupRegion?: string;
    /** 是否跨地域备份 */
    IsCrossRegionsBackup?: string;
}
/** 备份文件信息 */
export interface IBackupFileInfo {
    /** 快照文件ID（已废弃，请使用 BackupId） */
    SnapshotId: number;
    /** 备份文件名 */
    FileName: string;
    /** 备份文件大小 */
    FileSize: number;
    /** 备份开始时间 */
    StartTime: string;
    /** 备份完成时间 */
    FinishTime: string;
    /** 备份类型：snapshot / logic */
    BackupType: string;
    /** 备份方式：auto / manual */
    BackupMethod: string;
    /** 备份文件状态：success / fail / creating / deleting */
    BackupStatus: string;
    /** 备份文件时间 */
    SnapshotTime: string;
    /** 备份ID */
    BackupId: number;
    /** 快照类型：full / increment */
    SnapShotType: string;
    /** 备份文件备注 */
    BackupName: string;
}
/** 查询备份列表返回结果 */
export interface IDescribeBackupListResult {
    /** 总共备份文件个数 */
    TotalCount: number;
    /** 备份文件列表 */
    BackupList: IBackupFileInfo[];
}
/** 查询备份下载地址请求参数 */
export interface IDescribeBackupDownloadUrlOptions {
    /** 备份 ID */
    BackupId: number;
}
/** 查询备份下载地址返回结果 */
export interface IDescribeBackupDownloadUrlResult {
    /** 备份下载地址 */
    DownloadUrl: string;
}
/** 回档数据库信息 */
export interface IRollbackDatabase {
    /** 旧数据库名称 */
    OldDatabase: string;
    /** 新数据库名称 */
    NewDatabase: string;
}
/** 回档表信息 */
export interface IRollbackTableInfo {
    /** 旧表名称 */
    OldTable: string;
    /** 新表名称 */
    NewTable: string;
}
/** 回档数据库及表 */
export interface IRollbackTable {
    /** 数据库名称 */
    Database: string;
    /** 数据库表 */
    Tables: IRollbackTableInfo[];
}
/** 集群回档请求参数 */
export interface IRollBackClusterOptions {
    /** 回档策略：timeRollback（按时间点）、snapRollback（按备份文件） */
    RollbackStrategy: string;
    /** 备份文件ID，snapRollback 时必填 */
    RollbackId?: number;
    /** 期望回档时间，timeRollback 时必填 */
    ExpectTime?: string;
    /** 期望阈值（已废弃） */
    ExpectTimeThresh?: number;
    /** 回档数据库列表 */
    RollbackDatabases?: IRollbackDatabase[];
    /** 回档数据库表列表 */
    RollbackTables?: IRollbackTable[];
    /** 按时间点回档模式：full（普通，默认）、db（快速）、table（极速） */
    RollbackMode?: string;
}
/** 回档返回结果 */
export interface IRollBackClusterResult {
    /** 任务流 ID */
    FlowId: number;
}
