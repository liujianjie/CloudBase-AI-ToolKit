import { Environment } from '../environment';
import { IResponseInfo } from '../interfaces';
import { ICreateMySQLOptions, ICreateMySQLResult, IDescribeCreateMySQLResult, IMySQLClusterDetail, IDestroyMySQLResult, IMySQLTaskStatus, IRunSqlOptions, IRunSqlResult, ICreateAccountsOptions, IDeleteAccountsOptions, IDescribeAccountsOptions, IDescribeAccountsResult, IModifyAccountDescriptionOptions, IModifyAccountHostOptions, IModifyAccountParamsOptions, IModifyAccountPrivilegesOptions, IDescribeAccountPrivilegesOptions, IDescribeAccountPrivilegesResult, IDescribeAccountAllGrantPrivilegesResult, IResetAccountPasswordOptions, IInputAccount, IWanOptions, IWanResult, ICreateBackupOptions, ICreateBackupResult, IDeleteBackupOptions, IModifyBackupConfigOptions, IDescribeBackupListOptions, IDescribeBackupListResult, IDescribeBackupDownloadUrlOptions, IDescribeBackupDownloadUrlResult, IRollBackClusterOptions, IRollBackClusterResult, IDescribeTasksOptions, IDescribeTasksResult, IDescribeClusterDatabasesOptions, IDescribeClusterDatabasesResult, IDescribeClusterDatabaseTablesOptions, IDescribeClusterDatabaseTablesResult, IDescribeClusterInstanceGroupsResult, IDescribeInstancesOptions, IDescribeInstancesResult, IRestartInstanceOptions, IRestartInstanceResult, IDescribeInstanceDetailOptions, IDescribeInstanceDetailResult, IUpgradeInstanceOptions, IUpgradeInstanceResult, IDescribeInstanceSlowQueriesOptions, IDescribeInstanceSlowQueriesResult, IDescribeInstanceErrorLogsOptions, IDescribeInstanceErrorLogsResult } from './types/index';
export * from './types/index';
export declare class MysqlService {
    static tcbServiceVersion: {
        service: string;
        version: string;
    };
    static cynosdbServiceVersion: {
        service: string;
        version: string;
    };
    private environment;
    private envId;
    private cynosdbService;
    private tcbService;
    private _clusterId;
    private _instanceGroupId;
    constructor(environment: Environment);
    /**
     * 获取集群 ID（如未手动设置，则自动通过 describeClusterDetail 获取并缓存）
     */
    get clusterId(): string;
    /**
     * 手动设置集群 ID（适用于已知 clusterId 的场景，避免额外 API 调用）
     */
    set clusterId(id: string);
    /**
     * 开通 MySQL
     * 开通后可通过 describeCreateResult 查询开通结果
     * @param options 开通参数
     * @returns 返回包含 TaskId 的结果
     */
    createMySQL(options: ICreateMySQLOptions): Promise<{
        Data: ICreateMySQLResult;
    } & IResponseInfo>;
    /**
     * 开通 MySQL 结果查询
     * @param taskId OpenMySQL 返回的任务 ID（可选）
     * @returns 开通结果状态
     */
    describeCreateResult(taskId?: string): Promise<{
        Data: IDescribeCreateMySQLResult;
    } & IResponseInfo>;
    /**
     * 查询 MySQL 集群信息
     * @returns MySQL 集群详情
     */
    describeClusterDetail(): Promise<{
        Data: IMySQLClusterDetail;
    } & IResponseInfo>;
    /**
     * 销毁 MySQL
     * 销毁后可通过 describeTaskStatus 查询销毁结果
     * @returns 销毁结果（包含 TaskId、TaskName）
     */
    destroyMySQL(): Promise<{
        Data: IDestroyMySQLResult;
    } & IResponseInfo>;
    /**
     * 查询 MySQL 任务状态（销毁等异步任务的结果查询）
     * @param options 查询参数
     * @param options.taskId 任务 ID
     * @param options.taskName 任务名称
     * @returns 任务状态
     */
    describeTaskStatus(options?: {
        taskId?: string;
        taskName?: string;
    }): Promise<{
        Data: IMySQLTaskStatus;
    } & IResponseInfo>;
    /**
     * 执行 SQL 语句
     * @param options SQL 执行参数
     * @returns 查询结果（Items、Infos、RowsAffected）
     */
    runSql(options: IRunSqlOptions): Promise<IRunSqlResult>;
    /**
     * 查询集群实例组信息
     * 通过 CynosDB 原生接口获取真实的 InstanceGroupId 等信息
     * @returns 实例组列表
     */
    describeClusterInstanceGroups(): Promise<IDescribeClusterInstanceGroupsResult & IResponseInfo>;
    /**
     * 关闭外网访问
     * @param options 实例 ID 或实例组 ID（二选一）；均不传时自动获取实例组 ID
     * @returns 任务流 ID
     */
    closeWan(options?: IWanOptions): Promise<IWanResult & IResponseInfo>;
    /**
     * 开启外网访问
     * @param options 实例 ID 或实例组 ID（二选一）；均不传时自动获取实例组 ID
     * @returns 任务流 ID
     */
    openWan(options?: IWanOptions): Promise<IWanResult & IResponseInfo>;
    /**
     * 查询任务列表
     * @param options 查询参数
     * @returns 任务列表
     */
    describeTasks(options?: IDescribeTasksOptions): Promise<IDescribeTasksResult & IResponseInfo>;
    /**
     * 查询实例列表
     * @param options 查询参数（分页、排序、过滤条件等）
     * @returns 实例列表和总数
     */
    describeInstances(options?: IDescribeInstancesOptions): Promise<IDescribeInstancesResult & IResponseInfo>;
    /**
     * 查询实例详情
     * @param options 包含实例 ID
     * @returns 实例详细信息
     */
    describeInstanceDetail(options: IDescribeInstanceDetailOptions): Promise<IDescribeInstanceDetailResult & IResponseInfo>;
    /**
     * 重启实例
     * @param options 包含实例 ID
     * @returns 异步任务 FlowId
     */
    restartInstance(options: IRestartInstanceOptions): Promise<IRestartInstanceResult & IResponseInfo>;
    /**
     * 实例变配（升级/降级实例规格）
     * @param options 变配参数（实例 ID、CPU、内存、升级类型等）
     * @returns 订单号和冻结流水 ID
     */
    upgradeInstance(options: IUpgradeInstanceOptions): Promise<IUpgradeInstanceResult & IResponseInfo>;
    /**
     * 查询实例慢查询日志
     * @param options 查询参数（实例 ID、时间范围、分页、排序等）
     * @returns 慢查询日志列表和总数
     */
    describeInstanceSlowQueries(options: IDescribeInstanceSlowQueriesOptions): Promise<IDescribeInstanceSlowQueriesResult & IResponseInfo>;
    /**
     * 查询实例错误日志
     * @param options 查询参数（实例 ID、时间范围、分页、排序、日志等级等）
     * @returns 错误日志列表和总数
     */
    describeInstanceErrorLogs(options: IDescribeInstanceErrorLogsOptions): Promise<IDescribeInstanceErrorLogsResult & IResponseInfo>;
    /**
     * 查询集群数据库列表
     * @param options 分页参数
     * @returns 数据库名称列表
     */
    describeClusterDatabases(options?: IDescribeClusterDatabasesOptions): Promise<IDescribeClusterDatabasesResult & IResponseInfo>;
    /**
     * 查询集群数据库表列表
     * @param options 查询参数（包含数据库名）
     * @returns 数据库表列表
     */
    describeClusterDatabaseTables(options: IDescribeClusterDatabaseTablesOptions): Promise<IDescribeClusterDatabaseTablesResult & IResponseInfo>;
    /**
     * 创建用户账号
     * @param options 账号信息
     * @returns RequestId
     */
    createAccounts(options: ICreateAccountsOptions): Promise<IResponseInfo>;
    /**
     * 删除用户账号
     * @param options 要删除的账号列表
     * @returns RequestId
     */
    deleteAccounts(options: IDeleteAccountsOptions): Promise<IResponseInfo>;
    /**
     * 查询账号所有可授予权限
     * @param account 账号信息
     * @returns 全局权限、数据库权限、表权限等
     */
    describeAccountAllGrantPrivileges(account: IInputAccount): Promise<IDescribeAccountAllGrantPrivilegesResult & IResponseInfo>;
    /**
     * 查询数据库账号列表
     * @param options 查询参数
     * @returns 账号列表和总数
     */
    describeAccounts(options?: IDescribeAccountsOptions): Promise<IDescribeAccountsResult & IResponseInfo>;
    /**
     * 查询账号已有权限
     * @param options 查询参数
     * @returns 权限列表
     */
    describeAccountPrivileges(options: IDescribeAccountPrivilegesOptions): Promise<IDescribeAccountPrivilegesResult & IResponseInfo>;
    /**
     * 修改数据库账号描述信息
     * @param options 修改参数
     * @returns RequestId
     */
    modifyAccountDescription(options: IModifyAccountDescriptionOptions): Promise<IResponseInfo>;
    /**
     * 修改账号主机
     * @param options 修改参数
     * @returns RequestId
     */
    modifyAccountHost(options: IModifyAccountHostOptions): Promise<IResponseInfo>;
    /**
     * 修改账号配置
     * @param options 修改参数
     * @returns RequestId
     */
    modifyAccountParams(options: IModifyAccountParamsOptions): Promise<IResponseInfo>;
    /**
     * 修改账号库表权限
     * @param options 修改参数
     * @returns RequestId
     */
    modifyAccountPrivileges(options: IModifyAccountPrivilegesOptions): Promise<IResponseInfo>;
    /**
     * 重置数据库账号密码
     * @param options 重置参数
     * @returns RequestId
     */
    resetAccountPassword(options: IResetAccountPasswordOptions): Promise<IResponseInfo>;
    /**
     * 创建手动备份
     * @param options 备份参数
     * @returns 异步任务流 ID
     */
    createBackup(options?: ICreateBackupOptions): Promise<ICreateBackupResult & IResponseInfo>;
    /**
     * 删除手动备份（无法删除自动备份）
     * @param options 要删除的备份 ID
     * @returns RequestId
     */
    deleteBackup(options: IDeleteBackupOptions): Promise<IResponseInfo>;
    /**
     * 修改备份配置
     * @param options 备份配置参数
     * @returns RequestId
     */
    modifyBackupConfig(options: IModifyBackupConfigOptions): Promise<IResponseInfo>;
    /**
     * 查询备份文件列表
     * @param options 查询参数
     * @returns 备份文件列表
     */
    describeBackupList(options?: IDescribeBackupListOptions): Promise<IDescribeBackupListResult & IResponseInfo>;
    /**
     * 查询备份下载地址
     * @param options 备份 ID
     * @returns 备份下载地址
     */
    describeBackupDownloadUrl(options: IDescribeBackupDownloadUrlOptions): Promise<IDescribeBackupDownloadUrlResult & IResponseInfo>;
    /**
     * 集群回档
     * @param options 回档参数
     * @returns 任务流 ID
     */
    rollBackCluster(options: IRollBackClusterOptions): Promise<IRollBackClusterResult & IResponseInfo>;
    /**
     * 确保 clusterId 已获取（内部使用，自动从集群信息中获取并缓存）
     */
    private ensureClusterId;
    /**
     * 确保 instanceGroupId 已获取（内部使用，通过 CynosDB 原生接口获取真实值并缓存）
     */
    private ensureInstanceGroupId;
    /**
     * 解析 Wan 操作的请求参数
     * 若用户未显式传入 InstanceId / InstanceGroupId，则自动获取实例组 ID
     */
    private resolveWanParams;
}
