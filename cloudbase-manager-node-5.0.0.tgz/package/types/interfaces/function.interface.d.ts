export interface IFunctionVPC {
    subnetId: string;
    vpcId: string;
}
export interface ICloudFunctionTrigger {
    name: string;
    type: string;
    config: string;
}
export interface ICloudFunctionConfig {
    timeout?: number;
    envVariables?: Record<string, string | number | boolean>;
    runtime?: string;
    vpc?: IFunctionVPC;
    installDependency?: boolean | 'TRUE' | 'FALSE';
    l5?: boolean | 'TRUE' | 'FALSE';
    asyncRunEnable?: boolean | 'TRUE' | 'FALSE';
    traceEnable?: boolean | 'TRUE' | 'FALSE';
    autoDeployClsTopicIndex?: boolean | 'TRUE' | 'FALSE';
    autoCreateClsTopic?: boolean | 'TRUE' | 'FALSE';
    dnsCache?: boolean | 'TRUE' | 'FALSE';
    publish?: boolean | 'TRUE' | 'FALSE';
    ignoreSysLog?: boolean;
    memorySize?: number;
    role?: string;
}
export interface LayerVersionSimple {
    LayerName: string;
    LayerVersion: number;
}
export interface IFunctionImageConfig {
    imageType: 'enterprise' | 'personal';
    imageUri: string;
    registryId?: string;
    entryPoint?: string;
    command?: string;
    args?: string;
    containerImageAccelerate?: boolean;
    imagePort?: number;
    commandList?: string[];
    argsList?: string[];
}
export interface ICloudFunction extends ICloudFunctionConfig {
    name: string;
    description?: string;
    type?: 'Event' | 'HTTP';
    protocolType?: 'WS';
    protocolParams?: {
        wsParams?: {
            idleTimeOut?: number;
        };
    };
    instanceConcurrencyConfig?: {
        dynamicEnabled?: boolean | 'TRUE' | 'FALSE';
        maxConcurrency?: number;
        instanceIsolationEnabled?: boolean | 'TRUE' | 'FALSE';
        type?: string;
        mixNodeConfig?: any;
        sessionConfig?: any;
        [key: string]: any;
    };
    handler?: string;
    codeSecret?: string;
    isWaitInstall?: boolean;
    ignore?: string | string[];
    layers?: {
        name: string;
        version: number;
    }[];
    triggers?: ICloudFunctionTrigger[];
    imageConfig?: IFunctionImageConfig;
}
export interface ICloudFunctionV2 {
    name: string;
    config?: ICloudFunctionConfig;
    triggers?: ICloudFunctionTrigger[];
    params?: Record<string, string>;
    handler?: string;
    ignore?: string | string[];
    timeout?: number;
    envVariables?: Record<string, string | number | boolean>;
    runtime?: string;
    vpc?: IFunctionVPC;
    l5?: boolean;
    installDependency?: boolean;
    isWaitInstall?: boolean;
}
export interface IFunctionLogOptions {
    name: string;
    offset?: number;
    limit?: number;
    order?: string;
    orderBy?: string;
    startTime?: string;
    endTime?: string;
    requestId?: string;
}
export interface IFunctionLogOptionsV2 {
    name: string;
    offset?: number;
    limit?: number;
    startTime?: string;
    endTime?: string;
    requestId?: string;
    qualifier?: string;
}
export interface IFunctionLogDetailOptions {
    endTime?: string;
    logRequestId: string;
    startTime?: string;
}
export interface IFunctionInvokeRes {
    RequestId: string;
    Log: string;
    RetMsg: string;
    ErrMsg: string;
    MemUsage: number;
    Duration: number;
    BillDuration: number;
    FunctionRequestId: string;
    InvokeResult: number;
}
export interface IFunctionLogRes {
    RequestId: string;
    Data: [];
    TotalCount: number;
}
export interface IFunctionLogResV2 {
    RequestId: string;
    LogList: {
        RequestId: string;
        RetCode: number;
        RetryNum: number;
        StartTime: string;
    }[];
}
export interface IFunctionLogDetailRes {
    Context: string;
    Duration: number;
    ListOver: boolean;
    LogJson: string;
    MemUsage: number;
    RequestId: string;
    RetMsg: string;
    StartTime: string;
}
export interface IFunctionDownloadUrlRes {
    Url: string;
    RequestId: string;
    CodeSha256: string;
}
