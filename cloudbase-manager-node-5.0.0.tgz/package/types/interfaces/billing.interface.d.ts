import { IResponseInfo } from './base.interface';
export interface IGoodItem {
    GoodsCategoryId: number;
    RegionId: number;
    ZoneId: number;
    GoodsNum: number;
    ProjectId: number;
    PayMode: number;
    Platform: number;
    GoodsDetail: string;
}
export interface IGenerateDealsRes extends IResponseInfo {
    OrderIds: Array<string>;
}
export interface IPayDealsRes extends IResponseInfo {
    OrderIds: Array<string>;
    ResourceIds: Array<string>;
}
export interface PriceResInfo {
    GoodsDetail: string;
    GoodsCategoryId?: number;
    Region?: string;
    Zone?: string;
    GoodsNum?: number;
    Currency?: string;
    ProductCode?: string;
    SubProductCode?: string;
    PayMode?: string;
    ActivityId?: number;
    Purpose?: string;
    ActivityNumber?: string;
    Action?: string;
}
export interface CreateAuth {
    Version: string;
    SecretId: string;
    Timestamp: string;
    Signature: string;
    Nonce: string;
    Flag?: string;
}
export interface CalculatePriceParams {
    PriceType: string;
    ResInfo: PriceResInfo[];
    PayMode?: string;
    Auth?: CreateAuth;
    ClientUin?: string;
    AgentPay?: string;
    Anonymous?: boolean;
    DisplayDiscountDetail?: boolean;
}
export interface HighPrecisionPriceResult {
    [key: string]: any;
}
export interface PriceResult {
    Price: number;
    TotalCost: number;
    TimeUnit: string;
    TimeSpan: number;
    GoodsNum: number;
    ProductCode: string;
    SubProductCode: string;
    PartDetail: string;
    Policy: number;
    RealTotalCost: number;
    RefundDetail: string;
    RefundPayer: string;
    TaxRate?: number;
    Formula: string;
    HasUserPrice?: boolean;
    Currency?: string;
    HighPrecisionPrice?: HighPrecisionPriceResult;
    PolicyDetail?: string;
    New?: string;
    Old?: string;
    Refund?: string;
    AmountUnit?: string;
    PayerMode?: string;
    Action?: string;
    RefTaxDeal?: string;
    CountryIsoCode?: string;
    FormulaList?: string;
}
export interface CalculatePriceRes extends IResponseInfo {
    PriceInfos: Array<PriceResult>;
}
