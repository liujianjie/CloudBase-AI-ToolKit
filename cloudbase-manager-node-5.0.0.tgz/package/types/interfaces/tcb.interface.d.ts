import { IResponseInfo } from './base.interface';
export interface EndUserInfo {
    UUId?: string;
    WXOpenId?: string;
    QQOpenId?: string;
    Phone?: string;
    Email?: string;
    NickName?: string;
    Gender?: string;
    AvatarUrl?: string;
    UpdateTime?: string;
    CreateTime?: string;
}
export interface AuthDomain {
    Id?: string;
    Domain?: string;
    Type?: string;
    Status?: string;
    CreateTime?: string;
    UpdateTime?: string;
}
export interface LoginConfigItem {
    Platform?: string;
    PlatformId?: string;
    CreateTime?: string;
    UpdateTime?: string;
    Status?: string;
    Id?: string;
}
export interface FunctionLimit {
    NumberLimit?: number;
    CallLimit?: LimitInfo;
    ResourceUsageLimit?: LimitInfo;
    ConcurrentLimit?: number;
    OutboundTrafficLimit?: LimitInfo;
}
export interface StorageLimit {
    CapacityLimit?: number;
    DownloadLimit?: LimitInfo;
    UploadLimit?: LimitInfo;
    CdnOriginFlowLimit?: LimitInfo;
    CdnFlowLimit?: LimitInfo;
    UploadLimitMonthly?: LimitInfo;
    DownloadLimitMonthly?: LimitInfo;
}
export interface DatabaseLimit {
    CapacityLimit?: number;
    ConnectionLimit?: number;
    CollectionLimit?: number;
    IndexLimit?: number;
    ReadLimit?: LimitInfo;
    WriteLimit?: LimitInfo;
    QPSLimit?: number;
}
export interface LimitInfo {
    MaxSize?: number;
    TimeUnit?: string;
}
export interface UserInfo {
    OpenId?: string;
    GrantUserInfo?: boolean;
    NickName?: string;
    Country?: string;
    Province?: string;
    City?: string;
    Gender?: number;
    Language?: string;
    AvatarUrl?: string;
    CreateTime?: string;
    UpdateTime?: string;
}
export interface ResourcesInfo {
    ResourceType?: string;
    ResourceName: string;
    Status: number;
    MaxSize: number;
    CurSize: number;
    Unit: string;
}
export interface InvoicePostInfo {
    PostId: string;
    Contact?: string;
    Province?: string;
    City?: string;
    Address?: string;
    PostalCode?: string;
    Cellphone?: string;
}
export interface RecoverResult {
    Result?: string;
    ErrorMessage: string;
    RecoverJobId: string;
}
export interface RecoverJobStatus {
    JobId?: string;
    Status?: string;
    ErrorMessage: string;
}
export interface StorageException {
    Bucket?: string;
    COSStatus?: string;
    COSRecoverJobId: string;
}
export interface LogServiceException {
    LogsetName?: string;
    Status?: string;
    FunctionUpdateJobId: string;
}
export interface EnvInfo {
    EnvId?: string;
    Source?: string;
    Alias?: string;
    CreateTime?: string;
    UpdateTime?: string;
    Status?: string;
    Databases?: DatabasesInfo[];
    Storages?: StorageInfo[];
    Functions?: FunctionInfo[];
    PackageId: string;
    PackageName: string;
    LogServices: LogServiceInfo[];
    CustomLogServices: {
        CreateTime: string;
        ClsLogsetId: string;
        ClsTopicId: string;
        ClsRegion: string;
    }[];
    Region: string;
}
export interface FunctionInfo {
    Namespace?: string;
    Region?: string;
}
export interface DatabasesInfo {
    InstanceId?: string;
    Status?: string;
    Region?: string;
}
export interface StorageInfo {
    Region?: string;
    Bucket?: string;
    CdnDomain?: string;
    AppId?: string;
}
export interface LogServiceInfo {
    LogsetName?: string;
    LogsetId?: string;
    TopicName?: string;
    TopicId?: string;
    Region?: string;
}
export interface VoucherUseHistory {
    VoucherId?: string;
    UsedAmount?: number;
    UsedTime?: string;
    PayInfo?: string;
    SeqId?: string;
}
export interface Volucher {
    VoucherId?: string;
    OwnerUin?: string;
    Amount?: number;
    LeftAmount?: number;
    UseDeadLine?: string;
    Status: number;
    BaseAmount?: number;
}
export interface PackageInfo {
    PackageId?: string;
    Name?: string;
    Desc?: string;
    Detail?: string;
}
export interface EnvBillingInfoItem {
    EnvId?: string;
    PackageId?: string;
    IsAutoRenew?: boolean;
    Status?: string;
    PayMode?: string;
    IsolatedTime?: string;
    ExpireTime?: string;
    CreateTime?: string;
    UpdateTime?: string;
    IsAlwaysFree?: boolean;
    PaymentChannel?: string;
    PackageName?: string;
    ExtPackageCode?: {
        Code: string;
        Num: number;
    }[];
}
export interface InvoiceVATGeneral {
    TaxPayerType?: string;
    TaxPayerNumber?: string;
    BankDeposit?: string;
    BankAccount?: string;
    RegisterAddress?: string;
    RegisterPhone?: string;
}
export interface InvoiceVATSpecial {
    TaxPayerNumber?: string;
    BankDeposit?: string;
    BankAccount?: string;
    RegisterAddress?: string;
    RegisterPhone?: string;
}
export interface InvoiceBasicInfo {
    InvoiceId?: string;
    UserType?: string;
    Amount?: number;
    Status?: string;
    InvoiceTime?: string;
}
export interface QuotaOverlimit {
    ResourceName?: string;
    QuotaName?: string;
    QuotaChName?: string;
    QuotaUsaged?: number;
    Unit?: string;
    Comments: string;
}
export interface InvoiceAmountOverlimit {
    IsAmountOverlimit?: boolean;
    RefundAmount?: number;
    InvoiceAmount?: number;
}
export interface DealInfo {
    TranId?: string;
    DealOwner?: string;
    CreateTime?: string;
    PackageId?: string;
    DealStatus?: number;
    DealCost?: number;
    EnvId?: string;
    PayTime?: string;
    TimeSpan?: number;
    Price?: number;
    PayMode?: number;
    ProductName?: string;
    TimeUnit?: string;
    RefundAmount?: number;
    DealStatusDes: string;
    VoucherDecline: number;
    HasReturnPayCode: boolean;
}
export interface MonitorResource {
    Name?: string;
    Index?: string[];
    Period?: number[];
    EnIndex?: string[];
    EnName?: string;
    IndexUnit?: string[];
    Convergence?: number[];
    ConvergenceName?: string[];
}
export interface CollectionDispension {
    CollectionName?: string;
    DocCount?: number;
}
export interface MonitorPolicyInfo {
    Name?: string;
    PolicyId: number;
    Note?: string;
    Convergence?: number;
    ResType: string;
    ResName: string;
    Objects: string[];
}
export interface FileDownloadRespInfo {
    FileId?: string;
    DownloadUrl?: string;
    Code?: string;
}
export interface FileDownloadReqInfo {
    FileId?: string;
    TTL: number;
}
export interface FileDeleteInfo {
    FileId?: string;
    Code?: string;
}
export interface CommParam {
    OpenId: string;
    EnvName?: string;
    Module?: string;
}
export interface CloudBaseGWAPI {
    ServiceId: string;
    APIId: string;
    Path: string;
    Type: number;
    Name: string;
    CreateTime: number;
}
export interface CloudBaseGWService {
    ServiceId: string;
    Domain: string;
    OpenTime: number;
}
export interface ICreatePostpayRes extends IResponseInfo {
    TranId: string;
}
export interface ICreateFunctionHttpServiceRes extends IResponseInfo {
    APIId: string;
    Endpoint: string;
}
export interface IGWOrDomainNumRes extends IResponseInfo {
    Count: number;
}
export interface IHttpServiceDomainRes extends IResponseInfo {
    ServiceSet: Array<CloudBaseGWService>;
}
export interface CreateBillingDealParams {
    /** 下单操作类型 purchase 购买 | renew 续费 | modify 变配 */
    DealType: 'purchase' | 'renew' | 'modify';
    /** 购买的产品类型，可取[tcb-baas,tcb-promotion,tcb-package], 分别代表baas套餐、大促包、资源包 */
    ProductType: 'tcb-baas' | 'tcb-promotion' | 'tcb-package';
    /** 目标下单产品/套餐Id */
    PackageId: string;
    /** 是否自动支付 */
    CreateAndPay?: boolean;
    /** 购买时长 */
    TimeSpan?: number;
    /** 购买时长单位 d 天 | m 月 | y 年 | p 一次性 */
    TimeUnit?: 'd' | 'm' | 'y' | 'p';
    /** 资源唯一标识符 */
    ResourceId?: string;
    /** 来源 */
    Source?: 'qcloud' | 'miniapp';
    /** 资源别名 */
    Alias?: string;
    /** 环境id */
    EnvId?: string;
    /** 开启超限按量计费 */
    EnableExcess?: boolean;
    /** 变配目标产品/套餐id */
    ModifyPackageId?: string;
    /** jsonstr 附加信息 */
    Extension?: string;
    /** 是否自动选择代金券支付 */
    AutoVoucher?: boolean;
    /**
     * 资源类型
     * 代表新购环境（DealType=purchase 并且 ProductType=tcb-baas ）时需要发货哪些资源。
     * 可取值：flexdb, cos, cdn, scf
     */
    ResourceTypes?: string[];
}
export interface Tag {
    Key: string;
    Value: string;
}
export interface CreateEnvParams {
    Alias: string;
    PackageId: string;
    Resources: string[];
    Period?: number;
    AutoVoucher?: boolean;
    Tags?: Tag[];
    RenewFlag?: 'NOTIFY_AND_AUTO_RENEW' | 'NOTIFY_AND_MANUAL_RENEW';
}
export interface BaasPackageInfo {
    PackageName: string;
    PackageTitle: string;
    GroupName: string;
    GroupTitle: string;
    BillTags: string;
    ResourceLimit: string;
    AdvanceLimit: string;
    PackageDescription: string;
    IsExternal: boolean;
    UnitPrice: string;
}
export interface DescribeBaasPackageListParams {
    PackageName?: string;
    EnvId?: string;
    Source?: string;
    EnvChannel?: string;
    TargetAction?: string;
    GroupName?: string;
    PackageTypeList?: string[];
    PaymentChannel?: string;
    InternationalPackage?: boolean;
}
export interface ModifyEnvPlanParams {
    EnvId: string;
    PackageId: string;
    AutoVoucher?: boolean;
}
export interface RenewEnvParams {
    EnvId: string;
    Period?: number;
    AutoVoucher?: boolean;
}
export interface DestroyEnvParams {
    EnvId: string;
    IsForce?: boolean;
    BypassCheck?: boolean;
}
export interface DescribeEnvsParams {
    EnvId?: string;
    WxAppId?: string;
    IsVisible?: boolean;
    Channels?: string[];
    EnvType?: string;
    EnvTypes?: string[];
    Limit?: number;
    Offset?: number;
}
export interface DescribeEnvAccountCircleParams {
    EnvId: string;
    WxAppId?: string;
    WithHistoryCircle?: boolean;
}
export interface CircleTime {
    StartTime: string;
    EndTime: string;
}
export interface DescribeEnvAccountCircleRes extends IResponseInfo {
    StartTime: string;
    EndTime: string;
    HistoryTime: CircleTime[];
}
export interface DescribeCreditsUsageDetailParams {
    Modules: string[];
    StartDate: string;
    EndDate: string;
    NeedUsageDetails: boolean;
    EnvId: string;
}
export interface ValueDetail {
    CalcTime?: string;
    RawValue?: number;
    CreditsValue?: number;
    DeductValue?: number;
    PackageDeductValue?: number;
    ReportValue?: number;
    OriginCredits?: number;
}
export interface MetricUsage {
    MetricName?: string;
    ResourceType?: string;
    Value?: number;
    CreditsValue?: number;
    BillingCycleType?: string;
    Unit?: string;
    ValueDetailList?: ValueDetail[];
    DeductValue?: number;
    PackageDeductValue?: number;
    ReportValue?: number;
    OriginCredits?: number;
}
export interface EnvPkgCreditsUsage {
    EnvId?: string;
    Module?: string;
    CreditsValue?: number;
    MetricUsageDetail?: MetricUsage[];
    DeductValue?: number;
    PackageDeductValue?: number;
    ReportValue?: number;
    OriginCredits?: number;
}
