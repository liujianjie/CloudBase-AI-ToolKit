import { Environment } from '../environment';
import { IResponseInfo } from '../interfaces';
import { CloudrunServerType, ICloudrunDetailResponse, ICloudrunListResponse, ICloudrunServerBaseConfig, ICloudrunServerBaseInfo, IBuildLogResponse, IProcessLogResponse, IDiffConfigItem, ITemplate, ReleaseTypeEnum, IDescribeCloudRunDeployRecordResponse } from './type';
/**
 * 云托管服务管理类
 * 提供云托管服务的初始化、下载、列表查询和删除等功能
 */
export declare class CloudRunService {
    private environment;
    private tcbrService;
    private tcbService;
    constructor(environment: Environment);
    /**
     * 初始化云托管代码项目
     * @param {Object} params 初始化参数
     * @param {string} params.serverName 服务名称，将作为项目目录名
     * @param {string} [params.template='helloworld'] 模板标识符，默认为'helloworld'
     * @param {string} [params.targetPath='.'] 目标路径，默认为当前目录
     * @returns {Promise<void>}
     * @throws 当模板不存在、下载失败或解压失败时抛出错误
     */
    init(params: {
        serverName: string;
        template?: string;
        targetPath?: string;
    }): Promise<{
        projectDir: string;
    }>;
    /**
     * 下载云托管服务代码到本地目录
     * @param {Object} params 下载参数
     * @param {string} params.serverName 要下载的服务名称
     * @param {string} params.targetPath 下载的目标路径(绝对路径或相对路径)
     * @returns {Promise<void>}
     * @throws 当以下情况发生时抛出错误:
     * - 未找到服务版本
     * - 获取下载地址失败
     * - 下载或解压过程中出错
     */
    download(params: {
        serverName: string;
        targetPath: string;
    }): Promise<void>;
    /**
     * 获取云托管服务列表
     * @param {Object} [params] 查询参数
     * @param {number} [params.pageSize] 每页数量
     * @param {number} [params.pageNum] 页码
     * @param {string} [params.serverName] 服务名称筛选
     * @param {string} [params.serverType] 服务类型筛选
     * @returns {Promise<ICloudrunListResponse>} 包含服务列表和总数等信息的响应对象
     */
    list(params?: {
        pageSize?: number;
        pageNum?: number;
        serverName?: string;
        serverType?: CloudrunServerType;
    }): Promise<ICloudrunListResponse>;
    /**
     *
     * @param serverName 云托管服务名
     * @param stablePercent 稳定版本流量比例
     * @param canaryPercent 灰度版本流量比例
     * @returns 灰度发布进度
     */
    setTraffic(serverName: string, stablePercent: number, canaryPercent: number): Promise<{
        RequestId?: string;
    }>;
    /**
     *
     * @param serverName 云托管服务名
     * @returns 发布结果
     */
    promote(serverName: string): Promise<{
        RequestId?: string;
    }>;
    /**
     *
     * @param serverName 云托管服务名
     * @returns 回滚结果
     */
    rollback(serverName: string): Promise<{
        RequestId?: string;
    }>;
    /**
     *查询云托管服务详情
     * @param {Object} params 查询参数
     * @param {string} params.serverName 要查询的服务名称
     * @returns {Promise<ICloudrunDetailResponse>} 返回服务详情响应对象
     */
    detail(params: {
        serverName: string;
    }): Promise<ICloudrunDetailResponse>;
    /**
     * 删除指定的云托管服务
     * @param {string} serverName - 要删除的服务名称，必须是在当前环境中已存在的服务
     * @returns {Promise<IResponseInfo>} 返回删除操作的响应信息
     */
    delete(params: {
        serverName: string;
    }): Promise<IResponseInfo>;
    /**
     * 本地代码部署云托管服务
     * @param {Object} params 部署参数
     * @param {string} params.serverName 要部署的服务名称
     * @param {string} params.targetPath 本地代码路径
     * @param {Object} [params.serverConfig] 服务配置项(可选)
     * @param {string[]} [params.serverConfig.OpenAccessTypes] 开放访问类型
     * @param {number} [params.serverConfig.Cpu] CPU规格
     * @param {number} [params.serverConfig.Mem] 内存规格
     * @param {number} [params.serverConfig.MinNum] 最小实例数
     * @param {number} [params.serverConfig.MaxNum] 最大实例数
     * @param {Object} [params.serverConfig.PolicyDetails] 策略详情
     * @param {Object} [params.serverConfig.CustomLogs] 自定义日志配置
     * @param {Object} [params.serverConfig.EnvParams] 环境变量参数
     * @param {number} [params.serverConfig.Port] 端口(函数型服务不允许设置)
     * @param {string} [params.serverConfig.Dockerfile] Dockerfile路径
     * @param {string} [params.serverConfig.BuildDir] 构建目录
     * @param {boolean} [params.serverConfig.InternalAccess] 是否开启内网访问
     * @param {string} [params.serverConfig.InternalDomain] 内网域名
     * @param {string} [params.serverConfig.EntryPoint] 入口文件
     * @param {string} [params.serverConfig.Cmd] 启动命令
     * @returns {Promise<IResponseInfo>} 返回部署操作的响应信息
     */
    deploy(params: {
        serverName: string;
        targetPath: string;
        deployInfo: {
            ReleaseType: ReleaseTypeEnum;
        };
        serverConfig?: Partial<Pick<ICloudrunServerBaseConfig, 'OpenAccessTypes' | 'Cpu' | 'Mem' | 'MinNum' | 'MaxNum' | 'PolicyDetails' | 'CustomLogs' | 'EnvParams' | 'Port' | 'Dockerfile' | 'BuildDir' | 'InternalAccess' | 'InternalDomain' | 'EntryPoint' | 'Cmd' | 'InstallDependency'>>;
    }): Promise<IResponseInfo>;
    /**
     * 获取云托管服务模板列表
     * @returns {Promise<ITemplate[]>} 返回模板数组
     */
    getTemplates(): Promise<ITemplate[]>;
    /**
     * 获取部署记录列表，按部署时间倒序（最新在前）
     */
    getDeployRecords(params: {
        serverName: string;
    }): Promise<IDescribeCloudRunDeployRecordResponse>;
    getBuildLog(params: {
        serverName: string;
        buildId?: number;
    }): Promise<IBuildLogResponse>;
    getProcessLog(params: {
        RunId: string;
    }): Promise<IProcessLogResponse>;
    private _checkFunctionExist;
    private _upsertFunction;
}
export declare function codeToZip(cwd: string, options?: {
    installDependency?: boolean;
}): Promise<Buffer>;
/**
 * 将 object 参数转为 [{key:"Port", IntValue:80}] 的格式，并且剔除空字符串
 */
export declare function parseObjectToDiffConfigItem(data: Partial<ICloudrunServerBaseInfo>): IDiffConfigItem[];
