export declare enum CloudrunServerType {
    /**
     * 函数型服务
     */
    Function = "function",
    /**
     * 容器型服务
     */
    Container = "container"
}
export declare enum ReleaseTypeEnum {
    /**
     * 灰度发布
     */
    GRAY = "GRAY",
    /**
     * 全量发布
     */
    FULL = "FULL"
}
/**
 * 服务基础信息接口
 */
export interface ICloudrunServerBaseInfo {
    /**
     * 服务名称
     * @example "serverName"
     */
    ServerName: string;
    /**
     * 默认服务域名
     * @example "http://xxx.xxx.xxx"
     */
    DefaultDomainName: string;
    /**
     * 自定义域名
     * @example "http://xxx.xxx.xxx"
     */
    CustomDomainName: string;
    /**
     * 服务状态（来自 DescribeCloudRunServers）
     * 常见值："creating" | "create_failed" | "freezing" | "freeze_fail" | "froze" |
     * "unfreezing" | "unfreeze_fail" | "normal" | "deleting" | "delete_failed" | "abnormal"
     * @example "normal"
     */
    Status: 'creating' | 'create_failed' | 'freezing' | 'freeze_fail' | 'froze' | 'unfreezing' | 'unfreeze_fail' | 'normal' | 'deleting' | 'delete_failed' | 'abnormal';
    /**
     * 更新时间
     * @example "2022-03-09 14:00:00"
     */
    UpdateTime: string;
    /**
     * 公网访问类型数组
     * @example ["OA","MINIAPP","VPC"]
     */
    AccessTypes: string[];
    /**
     * 展示自定义域名数组
     * @example ["http://xxx.xxx.xxx","http://xxx.xxx.xxx"]
     */
    CustomDomainNames: string[];
    /**
     * 服务类型
     * @example "function" | "container"
     */
    ServerType: CloudrunServerType;
    /**
     * 流量类型（请根据实际业务补充具体类型定义）
     */
    TrafficType?: string;
}
/**
 * 扩缩容策略配置
 */
export interface ICloudrunHpaPolicy {
    /**
     * 扩缩容类型
     * @example "cpu" | "mem" | "cpu/mem"
     */
    PolicyType: string;
    /**
     * 扩缩容阈值(百分比)
     * @example 60
     */
    PolicyThreshold: number;
}
/**
 * 定时扩缩容配置
 */
export interface ICloudrunTimerScale {
    /**
     * 循环类型
     * @example "none"
     */
    CycleType?: string;
    /**
     * 循环起始日期
     * @example "2022-09-08"
     */
    StartDate?: string;
    /**
     * 循环结束日期
     * @example "2022-09-08"
     */
    EndDate?: string;
    /**
     * 起始时间
     * @example "00:00:00"
     */
    StartTime?: string;
    /**
     * 结束时间
     * @example "23:59:00"
     */
    EndTime?: string;
    /**
     * 副本个数
     * @example 1
     */
    ReplicaNum?: number;
}
/**
 * 服务基础配置信息
 */
export interface ICloudrunServerBaseConfig {
    /**
     * 环境 ID
     * @example "test-1gbtbgkjf8f48e2c"
     */
    EnvId: string;
    /**
     * 服务名称
     * @example "server-name"
     */
    ServerName: string;
    /**
     * 公网访问类型数组
     * @example ["PUBLIC", "OA", "MINIAPP", "VPC", ""]
     */
    OpenAccessTypes: string[];
    /**
     * CPU 规格
     * @example 0.25
     */
    Cpu: number;
    /**
     * 内存规格
     * @example 0.25
     */
    Mem: number;
    /**
     * 最小副本数
     * @example 1
     */
    MinNum: number;
    /**
     * 最大副本数
     * @example 2
     */
    MaxNum: number;
    /**
     * 扩缩容配置
     * @example cpu, mem, cpu/mem
     */
    PolicyDetails: ICloudrunHpaPolicy[];
    /**
     * 日志采集路径
     * @example "stdout"
     */
    CustomLogs: string;
    /**
     * 环境变量
     * @example {"MYSQL_USERNAME":"root"}
     */
    EnvParams: string;
    /**
     * 延迟检测时间(秒)
     * @example 2
     */
    InitialDelaySeconds: number;
    /**
     * 创建时间
     * @example "2022-03-10 19:44:07"
     */
    CreateTime: string;
    /**
     * 服务端口
     * @example 8080
     */
    Port: number;
    /**
     * 是否有 Dockerfile
     * @example true
     */
    HasDockerfile: boolean;
    /**
     * Dockerfile 文件名
     * @example "Dockerfile"
     */
    Dockerfile: string;
    /**
     * 构建目录
     * @example "src/"
     */
    BuildDir: string;
    /**
     * 日志类型
     * @example "none" | "default" | "custom"
     */
    LogType?: string;
    /**
     * CLS 日志集 ID
     * @example "dafslakfjkdal"
     */
    LogSetId?: string;
    /**
     * CLS 主题 ID
     * @example "sfafkslkfj"
     */
    LogTopicId?: string;
    /**
     * 日志解析类型
     * @example "json" | "line"
     */
    LogParseType?: string;
    /**
     * 服务标签
     * @example "function"
     */
    Tag?: string;
    /**
     * 内网访问开关
     * @example "close" | "open"
     */
    InternalAccess?: string;
    /**
     * 内网域名
     * @example "https://sdfsdf"
     */
    InternalDomain?: string;
    /**
     * 运行模式
     * @example "custom"
     */
    OperationMode?: string;
    /**
     * 定时扩缩容配置
     */
    TimerScale?: ICloudrunTimerScale[];
    /**
     * Dockerfile EntryPoint 参数
     * @example ["echo", "test"]
     */
    EntryPoint?: string[];
    /**
     * Dockerfile Cmd 参数
     * @example ["echo", "test"]
     */
    Cmd?: string[];
    /**
     * 是否在线安装依赖，true 则本地不打包 node_modules，依赖在线装（如Docker）
     */
    InstallDependency?: boolean;
}
export interface IDiffConfigItem {
    Key: string;
    Value?: string;
    IntValue?: number;
    BoolValue?: boolean;
    FloatValue?: number;
    ArrayValue?: string[];
    PolicyDetails?: ICloudrunHpaPolicy[];
    TimerScale?: ICloudrunTimerScale[];
}
/**
 * 在线版本信息
 */
export interface ICloudrunOnlineVersionInfo {
    /**
     * 版本名称
     * @example "test-001"
     */
    VersionName: string;
    /**
     * 镜像URL
     * @example "imageurl"
     */
    ImageUrl: string;
    /**
     * 流量比例
     * @example "100"
     */
    FlowRatio: string;
}
/**
 * 服务列表响应接口
 */
export interface ICloudrunListResponse {
    /**
     * 服务列表数组
     */
    ServerList: ICloudrunServerBaseInfo[];
    /**
     * 服务总数
     * @example 10
     */
    Total: number;
    /**
     * 请求ID
     */
    RequestId: string;
}
/**
 * 服务详情响应接口
 */
export interface ICloudrunDetailResponse {
    /**
     * 服务基本信息
     */
    BaseInfo: ICloudrunServerBaseInfo;
    /**
     * 服务配置信息
     */
    ServerConfig: ICloudrunServerBaseConfig;
    /**
     * 在线版本信息
     */
    OnlineVersionInfos: ICloudrunOnlineVersionInfo[];
    /**
     * 请求ID
     */
    RequestId: string;
}
export interface ITemplate {
    identifier: string;
    title: string;
    description: string;
    runtimeVersion: string;
    language: string;
    zipFileStore: string;
}
export interface ITaskStepInfo {
    Name?: string;
    Status?: string;
    StartTime?: string;
    EndTime?: string;
    CostTime?: number;
    FailReason?: string;
}
export interface IServerManageTaskInfo {
    Id?: number;
    EnvId?: string;
    ServerName?: string;
    CreateTime?: string;
    ChangeType?: string;
    ReleaseType?: string;
    DeployType?: string;
    PreVersionName?: string;
    VersionName?: string;
    PipelineId?: number;
    PipelineTaskId?: number;
    ReleaseId?: number;
    Status?: string;
    Steps?: ITaskStepInfo[];
    FailReason?: string;
    OperatorRemark?: string;
}
export interface IObjectKVPriority {
    Key?: string;
    Value?: string;
    Priority?: number;
}
export interface IVersionInfo {
    VersionName?: string;
    FlowRatio?: number;
    Status?: string;
    CreatedTime?: string;
    UpdatedTime?: string;
    BuildId?: number;
    UploadType?: string;
    Remark?: string;
    UrlParam?: IObjectKV;
    Priority?: number;
    IsDefaultPriority?: boolean;
    FlowParams?: IObjectKVPriority[];
    MinReplicas?: number;
    MaxReplicas?: number;
    RunId?: string;
    Percent?: number;
    CurrentReplicas?: number;
    Architecture?: string;
}
export interface IObjectKV {
    Key: string;
    Value: string;
}
export interface IReleaseOrderInfo {
    Id?: number;
    ServerName?: string;
    CurrentVersion?: IVersionInfo;
    ReleaseVersion?: IVersionInfo;
    GrayStatus?: string;
    ReleaseStatus?: string;
    TrafficTypeValues?: IObjectKV[];
    TrafficType?: string;
    FlowRatio?: number;
    CreateTime?: string;
    IsReleasing?: boolean;
}
/**
 * DescribeCloudRunDeployRecord 单条部署记录
 */
export interface ICloudRunDeployRecordInfo {
    /** 部署 ID */
    DeployId: string;
    /** 部署时间，如 "2026-01-29 19:17:31" */
    DeployTime: string;
    /** 状态，如 "build_failed" | "running" 等 */
    Status: string;
    /** 运行版本 ID */
    RunId: string;
    /** 构建 ID */
    BuildId: number;
    /** 流量比例 0-100 */
    FlowRatio: number;
    /** 镜像地址 */
    ImageUrl: string;
    /** 扩缩容状态 */
    ScaleStatus: string;
    /** 是否已有流量 */
    HasTraffic: boolean;
    /** 流量类型 */
    TrafficType: string;
    /** 是否正在发布 */
    IsReleasing: boolean;
}
export interface IDescribeCloudRunDeployRecordResponse {
    DeployRecords: ICloudRunDeployRecordInfo[];
    RequestId: string;
}
/**
 * DescribeCloudRunBuildLog 返回的日志对象
 */
export interface IBuildLog {
    /** 日志总条数 */
    Total: number;
    /** 已返回条数 */
    Delivered: number;
    /** 日志内容 */
    Text: string;
    /** 是否还有更多 */
    More: boolean;
    /** 失败类型 */
    FailType: string;
    /** 失败原因 */
    FailReason: string;
}
/**
 * DescribeCloudRunBuildLog 响应
 */
export interface IBuildLogResponse {
    Log: IBuildLog;
    RequestId: string;
}
/**
 * DescribeCloudRunProcessLog 响应
 */
export interface IProcessLogResponse {
    /** 日志内容数组 */
    Logs: string[];
    /** 请求ID */
    RequestId: string;
}
