export declare function checkIsInScf(): boolean;
