import _fetch from 'node-fetch';
export declare function fetch(url: string, config?: Record<string, any>, proxy?: any): Promise<any>;
export declare function fetchStream(url: string, config?: Record<string, any>, proxy?: any): Promise<_fetch.Response>;
