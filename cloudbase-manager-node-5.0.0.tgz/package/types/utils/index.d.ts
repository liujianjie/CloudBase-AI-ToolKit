import { ITemplate } from '../cloudrun/type';
export * from './auth';
export * from './cloud-api-request';
export * from './cloudbase-request';
export * from './envLazy';
export * from './fs';
export * from './http-request';
export { guid6 } from './uuid';
interface IZipOption {
    dirPath: string;
    outputPath: string;
    ignore?: string | string[];
    pattern?: string;
}
export declare function compressToZip(option: IZipOption): Promise<unknown>;
/**
     * 检查是否应该跳过某个文件或文件夹
     * @param {string} entryPath 文件路径
     * @returns {boolean} 如果应该跳过则返回 true
     */
export declare function shouldSkipEntry(entryPath: string): boolean;
/**
 * 下载并解压压缩包到指定目录
 * @param {string} downloadUrl 压缩包下载地址
 * @param {string} targetPath 目标路径
 * @returns {Promise<void>}
 * @throws 当下载失败或解压失败时抛出错误
 */
export declare function downloadAndExtractRemoteZip(downloadUrl: string, targetPath: string): Promise<void>;
/**
 * 将文件上传到指定 URL 地址
 * @param {Object} options - 上传配置项
 * @param {string} options.url - 目标上传地址
 * @param {File|Blob|Buffer} options.file - 要上传的文件对象
 * @param {string} [options.method='POST'] - HTTP 方法，默认为 POST
 * @param {Object} [options.headers={}] - 自定义请求头
 * @param {boolean} [options.withCredentials=false] - 是否携带跨域凭据
 */
export declare function upload({ url, file, method, headers, withCredentials }: {
    url: string;
    file: File | Blob | Buffer;
    method?: string;
    headers?: Record<string, any>;
    withCredentials?: boolean;
}): Promise<{
    data: any;
    context: {
        response: import("node-fetch").Response;
        file: Buffer | File | Blob;
    };
}>;
export declare function getRuntime(): string;
export declare function getEnvVar(envName: string): string;
export declare function rsaEncrypt(data: string): string;
export declare function sleep(time: number): Promise<void>;
export declare function upperCaseStringFisrt(str: string): string;
export declare function upperCaseObjKey(object: any): any;
/**
 * 获取函数模板列表
 * @param type 函数模板类型，支持 'scfFunc' 和 'tcbrFunc'
 * @returns
 */
export declare function fetchTemplates(types: ('scfFunc' | 'tcbrFunc' | 'tcbrContainer')[]): Promise<ITemplate[]>;
export declare const formatTimeValue: (num: any) => string;
export declare const formatTimeByMs: (ms: number) => string;
export declare const getCompleteTimeRange: (timeRange: {
    startTime?: string;
    endTime?: string;
}) => {
    startTime: string;
    endTime: string;
};
export declare function successLog(msg: string): void;
