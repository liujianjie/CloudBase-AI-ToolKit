export interface ITag {
    TagKey: string;
    TagValue: string[];
}
/**
 * VPC
 */
export interface IVpc {
    VpcId: string;
    VpcName: string;
    CidrBlock: string;
    Ipv6CidrBlock: string;
    IsDefault: false;
    EnableMulticast: false;
    CreatedTime: string;
    EnableDhcp: boolean;
    DhcpOptionsId: string;
    DnsServerSet: string[];
    DomainName: string;
    TagSet: any[];
    AssistantCidrSet: any[];
}
/**
 * 子网
 */
export interface ISubnet {
    VpcId: string;
    SubnetId: string;
    SubnetName: string;
    CidrBlock: string;
    Ipv6CidrBlock: string;
    IsDefault: boolean;
    IsRemoteVpcSnat: boolean;
    EnableBroadcast: boolean;
    Zone: string;
    RouteTableId: string;
    NetworkAclId: string;
    TotalIpAddressCount: number;
    AvailableIpAddressCount: number;
    CreatedTime: string;
    TagSet: any[];
}
/**
 * 函数
 */
export interface IFunctionLog {
    FunctionName: string;
    RetMsg: string;
    RequestId: string;
    StartTime?: string;
    RetCode?: number;
    InvokeFinished?: number;
    Duration?: number;
    BillDuration?: number;
    MemUsage: number;
    Log?: string;
    Level?: string;
    Source?: string;
}
export interface ILogFilter {
    RetCode?: 'not0' | 'is0' | 'TimeLimitExceeded' | 'ResourceLimitExceeded' | 'UserCodeException';
}
export type IRegion = number;
export interface IEnvVariable {
    Key: string;
    Value: string;
}
export interface ITrigger {
    Name: string;
    Type: string;
    Config: string;
    TriggerName: string;
    TriggerDesc: string;
}
export interface IFunctionInfo {
    FunctionName: string;
    FunctionId: string;
    Runtime: string;
    Handler: string;
    CodeSize: number;
    Timeout: number;
    FunctionVersion: string;
    MemorySize: number;
    UseGpu: 'TRUE' | 'FALSE';
    CodeInfo: string;
    CodeResult: string;
    CodeError: string;
    ErrNo: number;
    Role: string;
    InstallDependency: 'FALSE' | 'TRUE';
    AddTime: string;
    ModTime: string;
    Namespace: string;
    Status: string;
    StatusDesc: string;
    Description: string;
    Tags: ITag[];
    VpcConfig: {
        VpcId?: string;
        SubnetId?: string;
        vpc?: string;
        subnet?: string;
    };
    Environment: {
        Variables: IEnvVariable[];
    };
    Type: string;
    EipConfig: {
        EipFixed: 'FALSE' | 'TRUE';
        Eips: string[];
    };
    PublicNetConfig: {
        PublicNetStatus: 'ENABLE' | 'DISABLE';
        EipConfig: {
            EipStatus: 'ENABLE' | 'DISABLE';
            EipAddress: string[];
        };
    };
    Triggers: ITrigger[];
    StatusReasons: {
        ErrorCode: string;
        ErrorMessage: string;
    }[];
    RequestId: string;
    Layers: ILayerVersionInfo[];
}
/**
 * 层版本信息
 * 被 GetFunction, ListLayerVersions, ListLayers 接口引用
 */
export interface ILayerVersionInfo {
    /**
     * 版本适用的运行时
     * @example ["Python3.10","Python3.9"]
     */
    CompatibleRuntimes?: string[];
    /**
     * 创建时间
     * @example 2024-11-22 16:52:21
     */
    AddTime?: string;
    /**
     * 版本描述
     * @example "a layer"
     */
    Description?: string;
    /**
     * 许可证信息
     * @example " "
     */
    LicenseInfo?: string | null;
    /**
     * 版本号
     * @example 1
     */
    LayerVersion?: number;
    /**
     * 层名称
     * @example "layer-name1"
     */
    LayerName?: string;
    /**
     * 层的具体版本当前状态
     * Active：正常状态
     */
    Status?: string;
    /**
     * Stamp
     * @example "Default"
     */
    Stamp?: string;
    /**
     * 返回层绑定的标签信息
     */
    Tags?: ITag1[];
}
export interface ITag1 {
    Key: string;
    Value: string[];
}
export interface IFunctionCode {
    CosBucketName?: string;
    CosObjectName?: string;
    CosBucketRegion?: string;
    TempCosObjectName?: string;
    ZipFile?: string;
    CosTimestamp?: string;
    ImageConfig?: {
        ImageType?: string;
        ImageUri?: string;
        RegistryId?: string;
        EntryPoint?: string;
        Command?: string;
        Args?: string;
        ContainerImageAccelerate?: boolean;
        ImagePort?: number;
        CommandList?: string[];
        ArgsList?: string[];
    };
}
export interface ILayerVersionItem {
    LayerName: string;
    LayerVersion: number;
}
export interface IFunctionUpdateAttribute {
    Code?: IFunctionCode;
    Description?: string;
    FunctionName: string;
    MemorySize?: number;
    Timeout?: number;
    UseGpu?: 'FALSE' | 'TRUE';
    Namespace?: string;
    Environment?: {
        Variables: IEnvVariable[];
    };
    VpcConfig?: {
        VpcId: string;
        SubnetId: string;
    };
    InstallDependency?: 'FALSE' | 'TRUE';
    PublicNetConfig?: {
        PublicNetStatus: string;
        EipConfig: {
            EipStatus: string;
            EipAddress: string[];
        };
    };
    Layers?: ILayerVersionItem[];
    ClsLogsetId?: string;
    ClsTopicId?: string;
    Runtime?: string;
    Handler?: string;
    Role?: string;
    L5Enable?: string | null;
    CodeSecret?: string;
    Type?: string;
    ProtocolType?: string;
    ProtocolParams?: {
        WSParams?: {
            IdleTimeOut?: number;
        };
    };
    InstanceConcurrencyConfig?: {
        DynamicEnabled?: 'FALSE' | 'TRUE';
        MaxConcurrency?: number;
    };
}
