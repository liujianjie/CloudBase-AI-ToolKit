import { Environment } from '../environment';
import { IResponseInfo, ICloudFunction, ICloudFunctionV2, IFunctionLogOptions, ICloudFunctionTrigger, IFunctionInvokeRes, IFunctionLogRes, IFunctionDownloadUrlRes, IFunctionLogDetailOptions, IFunctionLogDetailRes, IFunctionLogOptionsV2, IFunctionLogResV2 } from '../interfaces';
import { IFunctionInfo } from './types';
export interface IFunctionCode {
    func: ICloudFunction;
    functionRootPath?: string;
    base64Code?: string;
    functionPath?: string;
    deployMode?: 'cos' | 'zip' | 'image';
}
export interface ICreateFunctionParam {
    func: ICloudFunction & {
        path?: string;
    };
    functionRootPath?: string;
    force?: boolean;
    base64Code?: string;
    functionPath?: string;
    codeSecret?: string;
    deployMode?: 'cos' | 'zip' | 'image';
}
export interface IUpdateFunctionCodeParam {
    func: ICloudFunction;
    functionPath?: string;
    functionRootPath?: string;
    base64Code?: string;
    codeSecret?: string;
    deployMode?: 'cos' | 'zip' | 'image';
}
export interface IUpdateFunctionIncrementalCodeParam {
    func: ICloudFunction;
    functionRootPath: string;
    deleteFiles?: Array<string>;
    addFiles?: string;
}
export interface ICreateFunctionRes {
    triggerRes: IResponseInfo;
    configRes: IResponseInfo;
    codeRes?: IResponseInfo;
}
export interface IFunctionLayerOptions {
    contentPath?: string;
    base64Content?: string;
    name: string;
    runtimes: string[];
    description?: string;
    licenseInfo?: string;
}
export interface ICreateLayerResponse extends IResponseInfo {
    LayerVersion: number;
}
export interface ILayerOptions {
    name: string;
    version: number;
}
export interface IVersionListOptions {
    name: string;
    runtimes?: string[];
}
export interface ILayerListOptions {
    offset?: number;
    limit?: number;
    runtime?: string;
    searchKey?: string;
}
export interface ILayerVersionInfo {
    CompatibleRuntimes: string[];
    AddTime: string;
    Description: string;
    LicenseInfo: string;
    LayerVersion: number;
    LayerName: string;
    Status: string;
}
export interface IListLayerVersionsRes extends IResponseInfo {
    LayerVersions: Array<ILayerVersionInfo>;
}
export interface IListLayerRes extends IResponseInfo {
    Layers: Array<ILayerVersionInfo>;
    TotalCount: number;
}
export interface IGetLayerVersionRes extends IResponseInfo {
    CompatibleRuntimes: string[];
    CodeSha256: string;
    Location: string;
    AddTime: string;
    Description: string;
    LicenseInfo: string;
    LayerVersion: number;
    LayerName: string;
    Status: string;
}
export interface ISetProvisionedConcurrencyConfig {
    functionName: string;
    qualifier: string;
    versionProvisionedConcurrencyNum: number;
}
export interface IGetProvisionedConcurrencyConfig {
    functionName: string;
    qualifier?: string;
}
export interface IVersionProvisionedConcurrencyInfo {
    AllocatedProvisionedConcurrencyNum: number;
    AvailableProvisionedConcurrencyNum: number;
    Status: string;
    StatusReason: string;
    Qualifier: string;
}
export interface IGetProvisionedConcurrencyRes extends IResponseInfo {
    UnallocatedConcurrencyNum: number;
    Allocated: IVersionProvisionedConcurrencyInfo[];
}
export interface IPublishVersionParams {
    functionName: string;
    description?: string;
}
export interface IPublishVersionRes extends IResponseInfo {
    FunctionVersion: string;
    CodeSize: number;
    MemorySize: number;
    Description: string;
    Handler: string;
    Timeout: number;
    Runtime: string;
    Namespace: string;
}
export interface IListFunctionVersionParams {
    functionName: string;
    offset?: number;
    limit?: number;
    order?: string;
    orderBy?: string;
}
export interface IFunctionVersion {
    Version: string;
    Description: string;
    AddTime: string;
    ModTime: string;
    Status: string;
}
export interface IFunctionVersionsRes extends IResponseInfo {
    FunctionVersion: string[];
    Versions: IFunctionVersion[];
    TotalCount: number;
}
export interface IVersionMatch {
    Version: string;
    Key: string;
    Method: string;
    Expression: string;
}
export interface IVersionWeight {
    Version: string;
    Weight: number;
}
export interface IRoutingConfig {
    AdditionalVersionWeights?: IVersionWeight[];
    AddtionVersionMatchs?: IVersionMatch[];
}
export interface IUpdateFunctionAliasConfig {
    functionName: string;
    name: string;
    functionVersion: string;
    description?: string;
    routingConfig?: IRoutingConfig;
}
export interface IGetFunctionAlias {
    functionName: string;
    name: string;
}
export interface IGetFunctionAliasRes extends IResponseInfo {
    FunctionVersion: string;
    Name: string;
    RoutingConfig: IRoutingConfig;
    Description: string;
    AddTime: string;
    ModTime: string;
}
export interface IListFunctionOptions {
    limit?: number;
    offset?: number;
    envId: string;
}
export interface IFunctionBatchOptions {
    functions: ICloudFunctionV2[];
    envId: string;
    log?: boolean;
}
export interface IGetAsyncEventStatusRes extends IResponseInfo {
    Result: IAsyncEventStatus;
    RequestId: string;
}
export interface IAsyncEventStatus {
    InvokeRequestId: string;
    Status: string;
    StatusCode: number;
}
export interface IFunctionCodeOptions {
    envId: string;
    destPath: string;
    functionName: string;
    codeSecret?: string;
}
export interface ILayerDownloadOptions {
    name: string;
    version: number;
    destPath: string;
    force?: boolean;
}
export interface IAttachOptions {
    envId: string;
    layerName: string;
    layerVersion: number;
    functionName: string;
    codeSecret?: string;
}
export interface ISortOptions {
    envId: string;
    functionName: string;
    layers: ILayer[];
}
export interface ILayer {
    LayerName: string;
    LayerVersion: number;
}
export declare class FunctionService {
    private environment;
    private vpcService;
    private scfService;
    private tcbService;
    private userService;
    constructor(environment: Environment);
    /**
     * 增量更新函数代码
     * @param {IUpdateFunctionIncrementalCodeParam} funcParam
     * @returns {Promise<void>}
     * @memberof FunctionService
     */
    updateFunctionIncrementalCode(funcParam: IUpdateFunctionIncrementalCodeParam): Promise<IResponseInfo>;
    /**
     * 创建云函数
     * @param {ICreateFunctionParam} funcParam
     * @returns {(Promise<IResponseInfo | ICreateFunctionRes>)}
     */
    createFunction(funcParam: ICreateFunctionParam): Promise<IResponseInfo | ICreateFunctionRes>;
    /**
     * @param {number} [limit=20]
     * @param {number} [offset=0]
     * @returns {Promise<{
     *         Functions: Record<string, string>[]
     *         RequestId: string
     *         TotalCount: number
     *     }>}
     * @memberof FunctionService
     */
    getFunctionList(limit?: number, offset?: number): Promise<{
        Functions: Record<string, string>[];
        RequestId: string;
        TotalCount: number;
    }>;
    /**
     * 列出函数
     * @param {number} [limit=20]
     * @param {number} [offset=0]
     * @returns {Promise<Record<string, string>[]>}
     */
    listFunctions(limit?: number, offset?: number): Promise<Record<string, string>[]>;
    /**
     * 列出所有函数
     * @param {IListFunctionOptions} options
     * @returns {Promise<Record<string, string>[]>}
     */
    listAllFunctions(options: IListFunctionOptions): Promise<Record<string, string>[]>;
    /**
     * 删除云函数
     * @param {string} name 云函数名称
     * @param {string} qualifier 需要删除的版本号，不填默认删除函数下全部版本。
     * @returns {Promise<IResponseInfo>}
     */
    deleteFunction(name: string | {
        name: string;
    }): Promise<IResponseInfo>;
    /**
     * 批量删除云函数
     * @param {Object} options
     * @param {string[]} options.names 云函数名称列表
     * @returns {Promise<void>}
     */
    batchDeleteFunctions({ names }: {
        names: any;
    }): Promise<void>;
    /**
     * 获取云函数详细信息
     * @param {string} name 云函数名称
     * @returns {Promise<Record<string, string>>}
     */
    getFunctionDetail(name: string, codeSecret?: string): Promise<IFunctionInfo>;
    /**
     * 批量获取云函数详细信息
     * @param {Object} options
     * @param {string[]} options.names 云函数名称列表
     * @param {string} options.envId 环境 ID
     * @param {string} options.codeSecret
     * @returns {Promise<IFunctionInfo[]>}
     */
    batchGetFunctionsDetail({ names, envId, codeSecret }: {
        names: any;
        envId: any;
        codeSecret: any;
    }): Promise<IFunctionInfo[]>;
    /**
     * 获取函数日志
     * @deprecated 请使用 getFunctionLogsV2 代替
     * @param {{
    *         name: string
    *         offset: number
    *         limit: number
    *         order: string
    *         orderBy: string
    *         startTime: string
    *         endTime: string
    *         requestId: string
    *     }} options
    * @returns {Promise<IFunctionLogRes>}
    */
    getFunctionLogs(options: IFunctionLogOptions): Promise<IFunctionLogRes>;
    /**
 * 获取函数日志 ID 列表
 * @param {{
    *         name: string
    *         offset: number
    *         limit: number
    *         startTime: string
    *         endTime: string
    *         requestId: string
    *         qualifier: string
    *     }} options
    * @returns {Promise<IFunctionLogResV2>}
    */
    getFunctionLogsV2(options: IFunctionLogOptionsV2): Promise<IFunctionLogResV2>;
    /**
 * 根据函数日志 ID 查询日志详情
 * @param {{
    *         startTime: string
    *         endTime: string
    *         logRequestId: string
    *     }} options
    * @returns {Promise<IFunctionLogDetailRes>}
    */
    getFunctionLogDetail(options: IFunctionLogDetailOptions): Promise<IFunctionLogDetailRes>;
    /**
     * 获取函数的完整调用日志
     * 该方法会自动完成两步操作：1. 获取日志请求ID列表。 2. 根据ID列表获取每条日志的详细内容。
     * @param {IFunctionLogOptionsV2} options - 查询选项
     * @returns {Promise<IFunctionLogDetailRes[]>} 返回包含完整日志详情的数组
     */
    getCompleteFunctionLogs(options: IFunctionLogOptionsV2): Promise<IFunctionLogDetailRes[]>;
    /**
     * 更新云函数配置
     * @param {ICloudFunction} func 云函数配置
     * @returns {Promise<IResponseInfo>}
     */
    updateFunctionConfig(func: ICloudFunction): Promise<IResponseInfo>;
    /**
     *
     * @param {IUpdateFunctionCodeParam} funcParam
     * @returns {Promise<IResponseInfo>}
     * @memberof FunctionService
     */
    updateFunctionCode(funcParam: IUpdateFunctionCodeParam): Promise<IResponseInfo>;
    /**
     * 更新函数代码和配置（带进度信息）
     * 支持同时更新代码和配置，按顺序执行：等待就绪 → 更新代码 → 等待就绪 → 更新配置 → 等待就绪
     * @param options 更新选项
     * @returns 更新结果，包含耗时信息
     */
    updateFunctionWithProgress(options: {
        /** 函数名称 */
        name: string;
        /** 代码相关参数（可选），复用 IUpdateFunctionCodeParam（排除 func，由 name 替代） */
        code?: Omit<IUpdateFunctionCodeParam, 'func'>;
        /** 配置相关参数（可选），复用 ICloudFunction（排除 name，由外层 name 替代） */
        config?: Omit<ICloudFunction, 'name'>;
    }): Promise<{
        /** 总耗时（毫秒） */
        elapsedTime: number;
        /** 结果消息 */
        message: string;
        /** 详细步骤信息 */
        details: string[];
    }>;
    /**
     * 调用云函数
     * @param {string} name 云函数名称
     * @param {Record<string, any>} params 调用函数传入参数
     * @returns {Promise<IFunctionInvokeRes>}
     */
    invokeFunction(name: string, params?: Record<string, any>): Promise<IFunctionInvokeRes>;
    /**
     * 批量调用云函数
     * @param {IFunctionBatchOptions} options
     * @returns {Promise<IFunctionInvokeRes[]>}
     */
    batchInvokeFunctions(options: IFunctionBatchOptions): Promise<IFunctionInvokeRes[]>;
    /**
     * 复制云函数
     * @param {string} name 云函数名称
     * @param {string} newFunctionName 新的云函数名称
     * @param {string} targetEnvId 目标环境 Id
     * @param {boolean} [force=false] 是否覆盖同名云函数
     * @returns {Promise<IResponseInfo>}
     */
    copyFunction(name: string, newFunctionName: string, targetEnvId?: string, force?: boolean): Promise<IResponseInfo>;
    /**
     * 创建云函数触发器
     * @param {string} name 云函数名称
     * @param {ICloudFunctionTrigger[]} triggers 云函数触发器配置
     * @returns {Promise<IResponseInfo>}
     */
    createFunctionTriggers(name: string, triggers?: ICloudFunctionTrigger[]): Promise<IResponseInfo>;
    batchCreateTriggers(options: IFunctionBatchOptions): Promise<void>;
    /**
     * 删除云函数触发器
     * @param {string} name 云函数名称
     * @param {string} triggerName 云函数触发器名称
     * @returns {Promise<IResponseInfo>}
     */
    deleteFunctionTrigger(name: string, triggerName: string): Promise<IResponseInfo>;
    batchDeleteTriggers(options: IFunctionBatchOptions): Promise<void>;
    /**
     * 下载云函数代码
     * @param {IFunctionCodeOptions} options
     * @returns {Promise<void>}
     */
    downloadFunctionCode(options: IFunctionCodeOptions): Promise<void>;
    /**
     * 获取云函数代码下载 链接
     * @param {string} functionName
     * @param {string} [codeSecret]
     * @returns {Promise<IFunctionDownloadUrlRes>}
     * @memberof FunctionService
     */
    getFunctionDownloadUrl(functionName: string, codeSecret?: string): Promise<IFunctionDownloadUrlRes>;
    attachLayer(options: IAttachOptions): Promise<IResponseInfo>;
    unAttachLayer(options: IAttachOptions): Promise<IResponseInfo>;
    updateFunctionLayer(options: ISortOptions): Promise<IResponseInfo>;
    downloadLayer(options: ILayerDownloadOptions): Promise<void>;
    createLayer(options: IFunctionLayerOptions): Promise<ICreateLayerResponse>;
    deleteLayerVersion(options: ILayerOptions): Promise<IResponseInfo>;
    listLayerVersions(options: IVersionListOptions): Promise<IListLayerVersionsRes>;
    listLayers(options: ILayerListOptions): Promise<IListLayerRes>;
    getLayerVersion(options: ILayerOptions): Promise<IGetLayerVersionRes>;
    waitFunctionActive(funcName: string, codeSecret?: string): Promise<void>;
    /**
     * 设置预置并发
     * @private
     * @param {IProvisionedConcurrencyConfig} concurrencyConfig
     * @returns
     * @memberof FunctionService
     */
    setProvisionedConcurrencyConfig(concurrencyConfig: ISetProvisionedConcurrencyConfig): Promise<IResponseInfo>;
    /**
     * 获取函数预置并发详情
     * @private
     * @param {IGetProvisionedConcurrencyConfig} concurrencyConfig
     * @returns {Promise<IGetProvisionedConcurrencyRes>}
     * @memberof FunctionService
     */
    getProvisionedConcurrencyConfig(concurrencyConfig: IGetProvisionedConcurrencyConfig): Promise<IGetProvisionedConcurrencyRes>;
    /**
     * 删除预置并发
     * @private
     * @param {IGetProvisionedConcurrencyConfig} concurrencyConfig
     * @returns {Promise<IResponseInfo>}
     * @memberof FunctionService
     */
    deleteProvisionedConcurrencyConfig(concurrencyConfig: IGetProvisionedConcurrencyConfig): Promise<IResponseInfo>;
    /**
     * 发布新版本
     * @param {IPublishVersionParams} publishParams
     * @returns {Promise<IPublishVersionRes>}
     * @memberof FunctionService
     */
    publishVersion(publishParams: IPublishVersionParams): Promise<IPublishVersionRes>;
    /**
     * 查询函数版本详情
     * @param {IListFunctionVersionParams} listVersionParams
     * @returns {Promise<IFunctionVersionsRes>}
     * @memberof FunctionService
     */
    listVersionByFunction(listVersionParams: IListFunctionVersionParams): Promise<IFunctionVersionsRes>;
    /**
     *
     * @param {IUpdateFunctionAliasConfig} updateVersionConfigParams
     * @returns {Promise<IResponseInfo>}
     * @memberof FunctionService
     */
    updateFunctionAliasConfig(updateVersionConfigParams: IUpdateFunctionAliasConfig): Promise<IResponseInfo>;
    /**
     * 查询函数别名详情
     * @param {IGetFunctionAlias} params
     * @returns {Promise<IGetFunctionAliasRes>}
     * @memberof FunctionService
     */
    getFunctionAlias(params: IGetFunctionAlias): Promise<IGetFunctionAliasRes>;
    /**
     * 通过scf COS 上传方式（通过 GetTempCosInfo + COS SDK 上传）
     * 返回 TempCosObjectName 用于创建/更新函数
     */
    uploadFunctionZipToCosLegacy(options: IFunctionCode, installDependency: 'TRUE' | 'FALSE'): Promise<{
        Key: string;
    }>;
    /**
     * 新的 COS 上传方式（通过 DescribeBuildServiceCosInfo + PUT 上传）
     * 返回 CosTimestamp 用于创建/更新函数
     */
    uploadFunctionZipToCos(options: IFunctionCode, installDependency: 'TRUE' | 'FALSE'): Promise<{
        UnixTimestamp: string;
    }>;
    getCodeParams(options: IFunctionCode, installDependency: 'TRUE' | 'FALSE'): Promise<{
        ZipFile: string;
        CosBucketRegion?: undefined;
        TempCosObjectName?: undefined;
    } | {
        CosBucketRegion: string;
        TempCosObjectName: string;
        ZipFile?: undefined;
    }>;
    private createAccessPath;
    private getTempCosInfo;
    private retryCreateTrigger;
    /**
     * 获取函数配置信息
     * @private
     * @returns
     * @memberof FunctionService
     */
    private getFunctionConfig;
    /**
     * 获取日志cls配置信息
     */
    private getClsServiceConfig;
    /**
     * 获取 vpc 信息
     * @returns
     */
    private getVpcs;
    /**
     * 获取子网
     * @param {string} vpcId
     * @returns
     */
    private getSubnets;
}
