export type CategoryNode = string | {
    [key: string]: CategoryNode;
};
export interface Category {
    [key: string]: CategoryNode;
}
export interface ModuleDocs {
    [key: string]: CategoryNode;
}
export interface DocEntry {
    title: string;
    path: string;
}
export interface SearchHit {
    url: string;
    content: string | null;
    type: string;
    hierarchy: Record<string, string | null>;
}
export interface SearchResult {
    url: string;
    title: string;
    content: string | null;
}
