import { SearchResult, ModuleDocs } from './types';
export declare class DocsService {
    listModules(): Promise<string[]>;
    /**
     * Case: tcb docs read 快速开始
     * 根据模块名获取该模块下的所有文档（返回嵌套的对象结构）
     */
    listModuleDocs(moduleName: string): Promise<ModuleDocs>;
    /**
     * Case: tcb docs read <任意输入>
     * 统一的查找入口，自动识别输入格式并返回模块数据或文档URL
     *
     * 支持的输入格式：
     * 1. URL路径格式（包含 /，相对或完整）: tcb docs read quick-start/create-env
     * 2. 点分隔路径: tcb docs read 云托管.快速开始..NET 快速开始
     * 3. 模块名: tcb docs read 快速开始 「命中第一个 底下其他同理」
     * 4. 嵌套模块名: tcb docs read 微信生态（嵌套在"社区.最佳实践"下）
     * 5. 文档标题: tcb docs read 小程序快速开始
     * 6. 前缀模糊匹配: tcb docs read PHP（匹配 "PHP 快速开始"）
     */
    findByName(input: string): Promise<{
        type: 'module';
        data: ModuleDocs;
    } | {
        type: 'doc';
        data: string;
    }>;
    readDoc(docPath: string): Promise<string>;
    searchDocs(query: string): Promise<SearchResult[]>;
    private getCategory;
    private findByKeyPrefix;
    private findByDotPath;
    private searchDotPathInTree;
    private matchDotPath;
    private findNestedModule;
    private findDocPathByTitle;
}
