export type PermissionResourceType = 'function' | 'storage' | 'table' | 'collection';
export type BasePermission = 'READONLY' | 'PRIVATE' | 'ADMINWRITE' | 'ADMINONLY' | 'CUSTOM';
export interface ModifyResourcePermissionOptions {
    resourceType: PermissionResourceType;
    resource?: string;
    permission: BasePermission;
    securityRule?: string;
}
export interface ModifyResourcePermissionResp {
    Success: boolean;
}
export interface DescribeResourcePermissionOptions {
    resourceType: PermissionResourceType;
    resources?: string[];
}
export interface ResourcePermission {
    ResourceType?: PermissionResourceType;
    Resource?: string;
    Permission?: BasePermission | string;
    SecurityRule?: string;
}
export interface DescribeResourcePermissionResp {
    TotalCount: number;
    PermissionList: ResourcePermission[];
}
export type QueryConditionRel = 'eq' | 'neq' | 'lt' | 'gt' | 'gte' | 'lte' | 'in' | 'nin' | 'search';
export interface QueryConditionItem {
    Key: string;
    Rel: QueryConditionRel;
    Val: string;
    ValueType?: string;
}
export interface QueryCondition {
    Key: string;
    Value: string;
    QueryConditions?: QueryConditionItem[];
}
export interface WorkBenchFeatureItem {
    Code?: string;
    Name?: string;
    IsAccess?: boolean;
    ParentCode?: string;
    SubPermissions?: WorkBenchFeatureItem[];
}
export interface WorkBenchPermission {
    AllPermission?: boolean;
    PartPermission?: boolean;
    Permissions?: WorkBenchFeatureItem[];
}
export interface PermissionPolicyItem {
    ResourceType: string;
    Resource: string;
    ResourceName?: string;
    Permission?: string;
    Effect?: string;
    IsBindAllAccess?: boolean;
    SubResourceIdList?: string[];
    RowPermission?: QueryCondition[];
    FeatureAuth?: WorkBenchPermission;
    GatewayPolicyCode?: string;
    GatewayPolicyName?: string;
    GatewayPolicyDescription?: string;
    GatewayPolicyExpression?: string;
}
export interface CreateRoleOptions {
    roleName: string;
    roleIdentity: string;
    description?: string;
    memberUids?: string[];
    policies?: PermissionPolicyItem[];
}
export interface CreateRoleResp {
    RoleId?: string;
    MemberUids?: string[];
    Policies?: PermissionPolicyItem[];
}
export interface MemberInfo {
    Uid?: string;
    Name?: string;
    NickName?: string;
}
export interface RoleItem {
    RoleId?: string;
    RoleIdentity?: string;
    RoleName?: string;
    RoleType?: 'system' | 'custom';
    Description?: string;
    Members?: MemberInfo[];
    Policies?: PermissionPolicyItem[];
}
export interface DescribeRoleListOptions {
    pageNumber?: number;
    pageSize?: number;
    roleId?: string;
    roleIdentity?: string;
    roleName?: string;
    loadDetails?: boolean;
}
export interface DescribeRoleListResp {
    TotalCount?: number;
    CustomTotalCount?: number;
    SystemRoles?: RoleItem[];
    CustomRoles?: RoleItem[];
}
export interface ModifyRoleOptions {
    roleId: string;
    roleName?: string;
    description?: string;
    addMemberUids?: string[];
    removeMemberUids?: string[];
    addPolicies?: PermissionPolicyItem[];
    removePolicies?: PermissionPolicyItem[];
}
export interface ModifyRoleResp {
    Success?: boolean;
    AddedMemberUids?: string[];
    RemovedMemberUids?: string[];
    AddedPolicies?: PermissionPolicyItem[];
    RemovedPolicies?: PermissionPolicyItem[];
}
export interface DeleteRolesOptions {
    roleIds: string[];
}
export interface DeleteRolesResp {
    SuccessCount?: number;
    FailedCount?: number;
}
