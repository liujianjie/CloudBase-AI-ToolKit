import { Environment } from '../environment';
import { ModifyResourcePermissionOptions, ModifyResourcePermissionResp, DescribeResourcePermissionOptions, DescribeResourcePermissionResp, CreateRoleOptions, CreateRoleResp, DescribeRoleListOptions, DescribeRoleListResp, ModifyRoleOptions, ModifyRoleResp, DeleteRolesOptions, DeleteRolesResp } from './types';
export declare class PermissionService {
    private environment;
    private tcbService;
    constructor(environment: Environment);
    modifyResourcePermission(options: ModifyResourcePermissionOptions): Promise<{
        Data: ModifyResourcePermissionResp;
        RequestId: string;
    }>;
    describeResourcePermission(options: DescribeResourcePermissionOptions): Promise<{
        Data: DescribeResourcePermissionResp;
        RequestId: string;
    }>;
    createRole(options: CreateRoleOptions): Promise<{
        Data: CreateRoleResp;
        RequestId: string;
    }>;
    describeRoleList(options?: DescribeRoleListOptions): Promise<{
        Data: DescribeRoleListResp;
        RequestId: string;
    }>;
    modifyRole(options: ModifyRoleOptions): Promise<{
        Data: ModifyRoleResp;
        RequestId: string;
    }>;
    deleteRoles(options: DeleteRolesOptions): Promise<{
        Data: DeleteRolesResp;
        RequestId: string;
    }>;
}
