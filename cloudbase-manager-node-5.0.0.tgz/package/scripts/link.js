/**
 * Tencent is pleased to support the open source community by making CloudBaseFramework - 云原生一体化部署工具 available.
 *
 * Copyright (C) 2020 THL A29 Limited, a Tencent company.  All rights reserved.
 *
 * Please refer to license text included with this package for license details.
 */

const os = require('os')
const fs = require('fs')
const fse = require('fs-extra')
const del = require('del')
const path = require('path')
const mkdirp = require('mkdirp')
const { execSync } = require('child_process')
const { createSymlink } = require('@lerna/create-symlink')

const globalNpmPath = execSync('npm root -g', {
    encoding: 'utf-8'
}).trim()
// 如果不支持workspace 可以用下面写死
// const globalNpmPath = '/usr/local/lib/node_modules';

async function main() {
    const unlink = process.argv?.[2] === '-d'
    await linkCore(unlink)
}

async function linkCore(unlink = false) {
    const jsonString = await fs.readFileSync(path.join(__dirname, '../package.json'))
    const { name } = JSON.parse(jsonString)
    await link(path.join(process.cwd()), path.join(globalNpmPath, '@cloudbase/cli'), name, unlink)
}

function isSymlink(path) {
    const stats = fs.lstatSync(path)
    return stats.isSymbolicLink()
}

// 将 global tcb cli 工具中的 framework-core link 到 packages/framework-core
async function link(src, dest, packageName, unlink = false) {
    const prevCwd = process.cwd()
    const destPlugin = path.join(dest, 'node_modules', '@cloudbase')
    // 确保目录存在
    mkdirp.sync(destPlugin)
    // 切换 cwd
    process.chdir(destPlugin)

    const pathName = packageName.replace('@cloudbase/', '')
    const backupPathName = `${pathName}_backup`

    if (unlink) {
        if (fs.existsSync(pathName) && !isSymlink(pathName)) {
            console.log(`【失败】${pathName} 不是软链接`, process.cwd())
            return
        }

        if (fs.existsSync(pathName) && fs.existsSync(backupPathName)) {
            // 删除软链接
            del.sync([pathName])

            // 恢复备份
            fse.moveSync(backupPathName, pathName)

            // 删除软链接
            console.log('【成功】删除软链接：', process.cwd())
        } else {
            console.info(
                `不存在 ${pathName} 或 ${backupPathName}，请重装安装 npm i @cloudbase/cli -g`,
                process.cwd()
            )
        }
    } else {
        // 创建软链接

        if (fs.existsSync(pathName)) {
            if (!fs.existsSync(backupPathName)) {
                // 不存在备份则进行备份

                if (!isSymlink(pathName)) {
                    // 不是软链接才备份
                    fse.moveSync(pathName, backupPathName)
                }
            } else {
                // 存在备份则直接删除
                del.sync([pathName])
            }
        }

        await createSymlink(src, pathName, 'junction')
        console.log('【成功】创建软链接：', process.cwd())
    }

    // 切回源目录
    process.chdir(prevCwd)
}

main()
